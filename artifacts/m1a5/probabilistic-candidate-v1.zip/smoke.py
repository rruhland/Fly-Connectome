from pathlib import Path
import torch
import probabilistic_visual_state

torch.set_num_threads(1)
root = Path(__file__).resolve().parent
assert Path(probabilistic_visual_state.__file__).resolve().parent == root
model = probabilistic_visual_state.ProbabilisticVisualState.load(root/'candidate.pt')
result = model.step(torch.zeros(2, 64, 64), torch.zeros(64, 64))
assert result['support_field'].shape == (64, 64)
assert not result['entities']
assert all(len(m.keys) for m in model.dynamics.values())
print('Isolated bundled runtime and checkpoint: PASS')
