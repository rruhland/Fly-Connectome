"""Validate held-out matched native Pong results and compare the learned angle with controls."""
import hashlib
import json
from pathlib import Path

from run_arcade_alternation import save
from run_pong_score_placement import paired_difference, retention_difference


ROOT = Path(__file__).resolve().parent


def record(row):
    requests = bytes.fromhex(row['actions'])
    hits = sum(bool(c['success']) for c in row['contacts'])
    if (row['action_sha256'] != hashlib.sha256(requests).hexdigest()
            or row['own_returns'] != hits or row['own_opportunities'] != len(row['contacts'])
            or row['own_hit_win'] != int(row['score'] == 1 and hits > 0)):
        raise ValueError('invalid public action or evaluator score receipt')
    return dict(row, contacts=[(c['camera'], c['success']) for c in row['contacts']], hits=hits,
                opportunities=row['own_opportunities'])


def trajectory(row):
    first = row['first_incoming']
    return None if first is None else {field: first[field] for field in first if field != 'success'}


def main():
    data = json.loads((ROOT / 'shot-cross-game-rows.json').read_bytes())
    conditions = {}
    for cap, arms in data.items():
        controls = {arm: [record(row) for row in rows] for arm, rows in arms.items()}
        source = controls['source_hockey']
        for arm, rows in controls.items():
            if [trajectory(row) for row in rows] != [trajectory(row) for row in source]:
                raise ValueError(f'first incoming trajectories differ for {cap} {arm}')
        conditions[cap] = {arm: dict(scoring=paired_difference(source, rows),
                                              returns=retention_difference(source, rows))
                           for arm, rows in controls.items() if arm != 'source_hockey'}
    save(ROOT / 'shot-cross-game-comparisons.json', conditions)


if __name__ == '__main__':
    main()
