"""Apply the visually learned native Pong angle slope to a hockey player's shot normal."""
import hashlib
import json
from pathlib import Path

import numpy as np

from air_hockey import AirHockeyCamera, HZ
from air_hockey_learning import GoalMemory, HockeyPlayer
from arcade_wall_learn import WallMemory
from run_arcade_alternation import save
from run_pong_score_placement import paired_difference


OUT = Path(__file__).resolve().parent
BASE_MULTIPLIER = .64
NORMAL_LIMIT = .62


class CalibratedHockeyPlayer(HockeyPlayer):
    def __init__(self, wall, goal, *, inverse_gain_scale, **kwargs):
        super().__init__(wall, goal, **kwargs)
        self.inverse_gain_scale = inverse_gain_scale

    def _normal(self, crossing, plane, incoming_angle):
        original = super()._normal(crossing, plane, incoming_angle)
        return min(NORMAL_LIMIT, max(-NORMAL_LIMIT, original * self.inverse_gain_scale))


def play(seed, rival, memory, *, gain=None, update=False):
    wall = WallMemory(default=1.)
    if gain is None:
        player = HockeyPlayer(wall, memory, seed=seed, learn_goals=update, explore=.40 if update else 0.)
    else:
        player = CalibratedHockeyPlayer(wall, memory, seed=seed, inverse_gain_scale=1 / (BASE_MULTIPLIER * gain))
    arena = AirHockeyCamera(seed, max_frames=540, opponent=rival)
    player.observe(arena.frame())
    actions = bytearray()
    while True:
        action = player.action()
        actions.append(action)
        frame, reward, terminated, truncated = arena.step(action)
        player.observe(frame, reward, terminated, truncated)
        if terminated or truncated:
            break
    hits = sum(event['kind'] == 'contact' and event['side'] == 'player' for event in arena.events)
    return dict(seed=seed, own_hit_win=int(reward == 1 and hits > 0), goals=int(reward == 1),
                losses=int(reward == -1), hits=hits, timeouts=int(truncated), seconds=arena.frames/HZ,
                actions=actions.hex(), action_sha256=hashlib.sha256(actions).hexdigest())


def main():
    hockey_fit_path = OUT / 'shot-hockey-fit.json'
    pong_fit_path = OUT / 'shot-cross-game-fits.json'
    hockey = json.loads(hockey_fit_path.read_bytes())
    pong = json.loads(pong_fit_path.read_bytes())
    rng = np.random.default_rng(51297216)
    prior = json.loads((OUT / 'shot-hockey-schedule.json').read_bytes())
    used = set(prior['practice'] + prior['heldout'])
    starts = []
    while len(starts) < 88:
        seed = int(rng.integers(1, 2147483647))
        if seed not in used:
            starts.append(seed)
            used.add(seed)
    schedule = dict(extra_practice=starts[:40], guard=starts[40:64], press=starts[64:])
    native = hockey['fit'][0]
    learned = pong['pong_angle_gain'] * pong['camera_reach']
    save(OUT / 'shot-pong-to-hockey-schedule.json', dict(schedule=schedule,
         pong_normalized_gain=learned, hockey_normalized_gain=native,
         input_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (hockey_fit_path,pong_fit_path)}))
    initial = GoalMemory.from_state(hockey['goal_state'])
    extra = GoalMemory.from_state(hockey['goal_state'])
    practice = [play(seed, 'guard', extra, update=True) for seed in schedule['extra_practice']]
    arms = {'archived':(initial,None), 'pong_fit':(initial,learned), 'pong_reflected':(initial,-learned),
            'matched_hockey_fit':(initial,native), 'extra_hockey':(extra,None)}
    rows = {}
    for rival in ('guard','press'):
        rows[rival] = {arm:[] for arm in arms}
        for seed in schedule[rival]:
            for arm, (memory,gain) in arms.items():
                rows[rival][arm].append(play(seed, rival, memory, gain=gain))
        print(rival, {arm:sum(row['own_hit_win'] for row in records) for arm,records in rows[rival].items()}, flush=True)
    save(OUT / 'shot-pong-to-hockey-rows.json', dict(evaluation=rows, extra_practice=practice))
    save(OUT / 'shot-pong-to-hockey-summary.json', {rival:dict(
         metrics={arm:{field:sum(row[field] for row in records)
             for field in ('own_hit_win','goals','losses','hits','timeouts','seconds')}
                  for arm,records in group.items()},
         contrasts={arm:paired_difference(group['pong_fit'], records) for arm,records in group.items()
                    if arm != 'pong_fit'}) for rival,group in rows.items()})


if __name__ == '__main__':
    main()
