"""Reconstruct the practice fit from saved requests and independently replayed cameras."""
from dataclasses import asdict
import json
from pathlib import Path
from statistics import median

from air_hockey import AirHockeyCamera
from air_hockey_learning import read_camera
from hockey_shot_transfer import HockeyShotObserver, fit_shot_response


ROOT = Path(__file__).resolve().parent


def main():
    data = json.loads((ROOT / 'shot-hockey-rows.json').read_bytes())
    frozen = json.loads((ROOT / 'shot-hockey-fit.json').read_bytes())
    trained = []
    for name, rows in data.items():
        for row in rows:
            arena = AirHockeyCamera(row['seed'], max_frames=540, opponent='guard')
            observer = HockeyShotObserver()
            observer.observe(read_camera(arena.frame()))
            observed = []
            for request in bytes.fromhex(row['actions']):
                frame, terminal, terminated, truncated = arena.step(request)
                contact = observer.observe(read_camera(frame))
                if contact is not None:
                    observed.append(contact)
            if (not (terminated or truncated) or terminal != row['terminal_reward']
                    or [asdict(shot) for shot in observed] != row['contacts']):
                raise ValueError(f'camera replay differs for {name} point {row["seed"]}')
            if name == 'practice':
                trained.extend(observed)
    reach = median(shot.separation for shot in trained)
    gain = fit_shot_response(trained, reach)
    if reach != frozen['reach'] or list(gain) != frozen['fit']:
        raise ValueError('practice replay does not reconstruct the frozen fit')
    print(f'Replay matched {sum(len(group) for group in data.values())} hockey points and gave identical fitted coefficients.')


if __name__ == '__main__':
    main()
