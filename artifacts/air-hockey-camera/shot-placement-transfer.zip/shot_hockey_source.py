"""Collect contact calibrations through real camera-only hockey practice."""
from dataclasses import asdict
from pathlib import Path

import numpy as np

from air_hockey import AirHockeyCamera, HZ
from air_hockey_learning import HockeyPlayer, GoalMemory
from arcade_wall_learn import WallMemory
from hockey_shot_transfer import HockeyShotObserver, fit_shot_response, predict_shot_angle
from run_arcade_alternation import save


OUT = Path(__file__).resolve().parent


def run(group, goals, wall, rng, learn):
    rows, samples = [], []
    for seed in group:
        player = HockeyPlayer(wall, goals, seed=int(rng.integers(2**31)),
                              learn_goals=learn, aim=True, explore=.40 if learn else 0.)
        observer = HockeyShotObserver()
        arena = AirHockeyCamera(seed, max_frames=540, opponent='guard')
        player.observe(arena.frame())
        observer.observe(player.image)
        contacts, requests = [], bytearray()
        while True:
            action = player.action()
            requests.append(action)
            frame, reward, terminated, truncated = arena.step(action)
            player.observe(frame, reward, terminated, truncated)
            contact = observer.observe(player.image)
            if contact is not None:
                contacts.append(contact)
            if terminated or truncated:
                break
        hits = [event for event in arena.events if event['kind'] == 'contact' and event['side'] == 'player']
        rows.append(dict(seed=seed, seconds=arena.frames / HZ, terminal_reward=reward,
                         contacts=[asdict(shot) for shot in contacts], true_contacts=hits,
                         actions=requests.hex()))
        samples.extend(contacts)
    return rows, samples


def main():
    rng = np.random.default_rng(7662291)
    seeds = [int(x) for x in rng.choice(2**31 - 1, size=64, replace=False)]
    goals, wall = GoalMemory(), WallMemory(default=1.)
    save(OUT / 'shot-hockey-schedule.json', dict(practice=seeds[:40], heldout=seeds[40:]))
    practice, samples = run(seeds[:40], goals, wall, rng, True)
    heldout, test = run(seeds[40:], goals, wall, rng, False)
    reach = float(np.median([shot.separation for shot in samples]))
    fit = fit_shot_response(samples, reach)
    raw, residual, baseline = [], [], []
    for sample in test:
        predicted = predict_shot_angle(sample, reach, fit)
        raw.append(sample.outgoing_angle)
        residual.append(sample.outgoing_angle - predicted)
        baseline.append(sample.outgoing_angle - fit[0] * sample.offset / reach)
    info = {}
    for name, rows in (('practice', practice), ('heldout', heldout)):
        info[name] = dict(games=len(rows), goals=sum(row['terminal_reward'] == 1 for row in rows),
                          recorded=sum(len(row['contacts']) for row in rows),
                          true_contacts=sum(len(row['true_contacts']) for row in rows),
                          misses=sum(all(abs(contact['seconds'] - hit['frame'] / HZ) > .045
                                          for hit in row['true_contacts'])
                                     for row in rows for contact in row['contacts']))
    save(OUT / 'shot-hockey-rows.json', dict(practice=practice, heldout=heldout))
    save(OUT / 'shot-hockey-fit.json', dict(reach=reach, fit=fit, cohorts=info, goal_state=goals.to_state(),
         test_rmse=dict(full=float(np.sqrt(np.mean(np.square(residual)))),
                        uncompensated_gain=float(np.sqrt(np.mean(np.square(baseline)))),
                        no_gain=float(np.sqrt(np.mean(np.square(raw)))))))


if __name__ == '__main__':
    main()
