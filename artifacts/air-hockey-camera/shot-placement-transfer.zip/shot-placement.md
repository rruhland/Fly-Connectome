# Air hockey rebound calibration and Pong shot placement

The hockey learner played 40 points against a moving opponent with its ordinary camera controller, goal-score learning and exploration. It received rendered frames, its own requested actions and goal rewards. A separate observer recovered inbound and outbound puck paths and striker motion from the same public images. It accepted forward reversals close to the visible striker and estimated contact time by intersecting the longitudinal paths. The fit used lateral contact offset divided by the median visible contact separation, incoming direction and transverse striker motion.

The observer recovered 49 contacts in 233.82 hockey seconds and 20 more on 24 held-out points. The physical audit matched every observation to an actual own contact within 6.3 ms. This detector selects clear front-face reversals, which were 49 of 264 recorded own contacts during practice. An independent replay matched all 64 saved action sequences and reconstructed the fitted coefficients exactly. On the 20 held-out shots, the three-term model predicted the physical outgoing angle with 0.383 radians of root mean squared error. The term for lateral offset alone produced 1.029 radians of error. A fixed straight exit produced 0.833. [Fit](shot-hockey-fit.json) · [Physical audit](shot-hockey-physics-audit.json) · [Recorded points](shot-hockey-rows.json)

The Pong comparison used the archived 60-life continuing learner, including its visual role, motor, timing and score state. The extra Pong practice followed that same learner for 40 chronological points and observed its public camera rebounds. The hockey slope became 15.30 radians per Pong image unit after normalization by the visible paddle and ball width. The extra native Pong fit gave 8.73 radians per image unit. The same candidate shot planner used the archived camera fit for the contact plane, ball speed, walls and opponent motion in its hockey, reflected, zero-angle and native-fit variants. This comparison tests whether carrying a single learned physics term adds scoring to a controller that already knows Pong. [Pong fits](shot-cross-game-fits.json) · [Held-out schedule](shot-cross-game-schedule.json)

An initial check measured eight inbound starts at each opponent speed. At .35 the archived scorer won 7, the forecast using the earlier camera-only Pong rebound fit won 6 and the zero-angle forecast won 1. At .42 they won 2, 0 and 0. All wins followed own contact. [Scout](shot-ceiling-summary.json)

## Pong calibration applied to hockey

The reciprocal test scaled the existing hockey aim by the inverse normalized Pong gain. All calibration arms started with the same learned hockey goal state. The equal-practice control continued goal learning for 40 additional hockey points. Each held-out block had 24 matched mixed serves. The ordinary hockey guard also appeared in practice. The pressing rival was a change at evaluation.

| Visual striker aim | Guard own-hit wins | Press own-hit wins |
| --- | ---: | ---: |
| Archived hockey policy | 12/24 | 17/24 |
| Native Pong camera fit | 14/24 | 15/24 |
| Sign-reflected Pong fit | 15/24 | 19/24 |
| Native hockey camera fit | 9/24 | 17/24 |
| Forty more hockey games | 14/24 | 19/24 |

The Pong-derived slope had no consistent scoring advantage across rivals. Even on the ordinary guard it scored fewer wins than the reflected slope. The nonlinear moving-striker contact and terminal goal learning provide several sources of uncertainty in transferring one lateral coefficient. [Scoring comparisons](shot-pong-to-hockey-summary.json) · [Matched receipts](shot-pong-to-hockey-rows.json)

## Hockey calibration applied to Pong

The main comparison used 12 held-out incoming serves at each opponent speed. The historical score policy and the policy with 40 more native practice points restored their saved score rule. The four forecast arms used one planner and varied its angular calibration. Extra native Pong practice took 217.88 game seconds and provided 41 camera-observed contacts. Hockey practice took 233.82 game seconds. The bootstrap interval for the hockey-derived coefficient was 11.55 to 18.02 radians per Pong image unit. [Native practice](shot-target-practice-rows.json) · [Hockey coefficient interval](shot-hockey-gain-bootstrap.json)

| Shot selection | .35 own-hit wins | .35 returns | .39 own-hit wins | .39 returns |
| --- | ---: | ---: | ---: | ---: |
| Archived 60-life learner | 12/12 | 19/19 | 6/12 | 23/24 |
| Forecast with hockey camera fit | 7/12 | 27/28 | 2/12 | 32/34 |
| Forecast with sign-reflected hockey fit | 2/12 | 34/34 | 2/12 | 34/35 |
| Forecast with zero angle response | 2/12 | 43/43 | 0/12 | 43/44 |
| Forty more native points with archived scorer | 12/12 | 17/17 | 6/12 | 23/24 |
| Forty more native points with native camera fit | 3/12 | 33/33 | 2/12 | 32/34 |

The hockey-calibrated forecast gained 41.7 percentage points over both the zero-angle and reflected forecasts at .35. Its paired 95% bootstrap interval was +16.7 to +66.7 points. It scored 41.7 points below the historical policy at .35 and 33.3 points below it at .39, with intervals of −66.7 to −16.7 and −58.3 to −8.3 points. At .39 the sign-reflected and actual hockey coefficients won the same two starts. The audit matched all policies' first incoming trajectories and verified all saved request hashes and contact totals. [Summary](shot-cross-game-summary.json) · [Paired comparisons](shot-cross-game-comparisons.json) · [Matched receipts](shot-cross-game-rows.json)
