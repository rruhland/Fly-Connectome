"""Bound the value of a camera-calibrated shot forecast in native Pong."""
from concurrent.futures import ProcessPoolExecutor
from dataclasses import replace
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile

import numpy as np
import torch

from arcade_alternation import AlternatingSession
from pong_reachable_placement import ReachablePlacement, ShotGeometry
from run_arcade_alternation import _PongLife, save
from run_pong_score_placement import paired_difference
from run_pong_surprise_recovery import exclusions


ROOT = Path('/workspace/Fly-Connectome-m1b')
OUT = Path(__file__).resolve().parent
CHECKPOINT = ROOT / 'artifacts/m2/2026-11-20-arcade-fixed-policy-session.json'
GEOMETRY = ROOT / 'artifacts/m1b/2026-11-19-pong-reachable-placement.zip'
ARMS = ('archived', 'zero_angle', 'known_angle', 'source_regression')
CAPS = (.35, .42)
TICKS = 120 * 12


class ShotForecast(ReachablePlacement):
    def __init__(self, core, geometry):
        self.core = core
        super().__init__(core.timing, geometry)

    @property
    def shot_memory(self):
        return self.core.shot_memory

    def choose(self, entities, baseline_action):
        self.core.entities = entities
        return super().choose(entities, baseline_action)

    def observe(self, **transition):
        return self.core.observe(**transition)


def play(session, seed, cap, geometry=None, observer=None, save_actions=False):
    arena = _PongLife(seed, cap, TICKS)
    life = session.begin_life()
    life.reset(arena.frame())
    forecast = None
    if geometry is not None:
        forecast = ShotForecast(life.life.controller, geometry)
        life.life.bridge.controller = forecast
    requested = bytearray()
    while True:
        action, _ = life.choose()
        requested.append(action)
        result = arena.step(action)
        life.observe(replace(result, physics_ticks=0, hits=0))
        if observer is not None:
            observer(life)
        if result.terminated or result.truncated:
            break
    session.end_life()
    row = arena.summary(result)
    row['own_hit_win'] = int(row['own_hit_win'])
    row['action_sha256'] = hashlib.sha256(requested).hexdigest()
    row['aim_choices'] = forecast.shots if forecast else []
    row['known'] = len(forecast.shots) if forecast else 0
    if save_actions:
        row['actions'] = requested.hex()
    return row


def trial(job):
    torch.set_num_threads(1)
    arm, seed, cap, geometry, state = job
    session = AlternatingSession.from_state(state)
    return arm, cap, play(session, seed, cap, geometry, save_actions=True)


def seeds(number, entropy, caps, *, incoming_only=False):
    used, _ = exclusions(OUT.parent)
    rng = np.random.default_rng(entropy)
    cases = {cap: [] for cap in caps}
    for cap, group in cases.items():
        while len(group) < number:
            seed = int(rng.integers(1, 2147483647))
            direction = ((seed * 48271 + 1) % 2147483647) % 2
            if seed in used or direction != (1 if incoming_only else len(group) % 2):
                continue
            used.add(seed)
            group.append(seed)
    return cases


def load():
    state = json.loads(CHECKPOINT.read_bytes())
    with ZipFile(GEOMETRY) as zipped:
        fit = json.loads(zipped.read('camera-forecast/geometry-final.json'))['geometry']
    return state, ShotGeometry(**fit)


def summarize(rows):
    return dict(starts=len(rows), own_hit_wins=sum(row['own_hit_win'] for row in rows),
                returns=sum(row['own_returns'] for row in rows),
                opportunities=sum(row['own_opportunities'] for row in rows),
                losses=sum(row['score'] < 0 for row in rows),
                natural=sum(row['natural_serve_win'] for row in rows),
                timeouts=sum(row['truncated'] for row in rows),
                choices=sum(row['known'] for row in rows),
                elapsed=sum(row['elapsed'] for row in rows))


def experiment(arms, cases, name, workers=2):
    results = {cap: {arm: [] for arm in arms} for cap in cases}
    jobs = [(arm, seed, cap, geom, state) for cap, group in cases.items()
            for seed in group for arm, (geom, state) in arms.items()]
    with ProcessPoolExecutor(max_workers=workers) as pool:
        for arm, cap, row in pool.map(trial, jobs):
            results[cap][arm].append(row)
            print(cap, arm, row['seed'], row['score'], row['own_returns'], row['own_opportunities'], row['known'], flush=True)
    save(OUT / f'{name}-rows.json', results)
    summary = {cap: dict(arms={arm: summarize(rows) for arm, rows in group.items()},
                         differences={arm: paired_difference(rows, group['archived'])
                                      for arm, rows in group.items() if arm != 'archived'})
               for cap, group in results.items()}
    save(OUT / f'{name}-summary.json', summary)


if __name__ == '__main__':
    receipt = OUT / 'shot-ceiling-schedule.json'
    cases = {float(cap): group for cap, group in json.loads(receipt.read_bytes())['schedule'].items()} if receipt.exists() else seeds(8, 41077131, CAPS, incoming_only=True)
    state, geometry = load()
    options = {'archived': (None, state),
               'zero_angle': (replace(geometry, angle_per_offset=0.), state),
               'known_angle': (geometry, state)}
    save(OUT / 'shot-ceiling-schedule.json', dict(schedule=cases, ticks=TICKS,
         arms={arm: {'angle': None if item[0] is None else item[0].angle_per_offset}
               for arm, item in options.items()},
         files={str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in (CHECKPOINT, GEOMETRY)}))
    experiment(options, cases, 'shot-ceiling')
