"""Compare a camera-only air-hockey rebound fit with strong native Pong controls."""
from dataclasses import replace
import hashlib
import json
from pathlib import Path
from statistics import median

import torch

from arcade_alternation import AlternatingSession
from breakout_visual_rebound import VisualRebounds
from pong_role_transfer import PIXEL, components
from run_arcade_alternation import digest, save
from shot_scout import OUT, CHECKPOINT, GEOMETRY, TICKS, experiment, load, play, seeds


CAPS = (.35, .39)
TEST_POINTS = 12
EXTRA_PONG_PRACTICE = 40


class PongObserver:
    def __init__(self):
        self.record = VisualRebounds()
        self.contacts = []
        self.reaches = []

    def __call__(self, life):
        detector = life.detector
        rebound = self.record.observe(detector.seconds, detector.canonical_entities, detector.pair_ids)
        if rebound is not None:
            self.contacts.append(rebound)
        if not self.reaches and detector.binding is not None:
            _, groups = components(detector.frame)
            axis, station = detector.binding.axis, detector.binding.station
            player = next((component for component in groups if component.rail is not None
                           and component.rail[0] == axis
                           and abs(component.position[1 - axis] - station) <= PIXEL), None)
            ball = next((component for component in groups if max(component.span) <= 3), None)
            if player is not None and ball is not None:
                self.reaches.append((player.span[axis] + ball.span[axis]) * PIXEL / 2)


def target_practice(state, cases):
    session = AlternatingSession.from_state(state)
    rows, observed, reaches = [], [], []
    for seed in cases:
        observation = PongObserver()
        rows.append(play(session, seed, CAPS[0], observer=observation, save_actions=True))
        observed.extend(observation.contacts)
        reaches.extend(observation.reaches)
        print('native_practice', seed, rows[-1]['score'], len(observation.contacts), flush=True)
    ratio = [shot.angle / shot.contact_offset for shot in observed if abs(shot.contact_offset) > .025]
    if len(ratio) < 4 or not reaches:
        raise ValueError('equal Pong practice did not observe enough informative native rebounds')
    return session.state(), rows, observed, reaches, median(ratio)


def main():
    torch.set_num_threads(1)
    state, geometry = load()
    fit_path = OUT / 'shot-hockey-fit.json'
    fit = json.loads(fit_path.read_bytes())
    case_file = OUT / 'shot-cross-game-schedule.json'
    if case_file.exists():
        schedule = json.loads(case_file.read_bytes())
        evaluation = {float(cap): group for cap, group in schedule['evaluation'].items()}
        practice = schedule['target_practice']
    else:
        evaluation = seeds(TEST_POINTS, 85508086, CAPS, incoming_only=True)
        practice = seeds(EXTRA_PONG_PRACTICE, 701032386, CAPS[:1], incoming_only=True)[CAPS[0]]
    if set(practice) & set(seed for group in evaluation.values() for seed in group):
        raise ValueError('practice and evaluation schedules must be disjoint')
    save(case_file, dict(evaluation=evaluation, target_practice=practice,
                         max_ticks=TICKS, practice_opponent=CAPS[0],
                         rules='One archived checkpoint per held-out game. Additional Pong practice '
                         'is chronological with the archived policy still learning. Width scaling '
                         'uses the median Pong camera silhouette measurement. Prior knowledge of '
                         'Pong flight and opponent dynamics is used in every forecast arm. The '
                         'source branch carries only a visually learned near-contact angle slope.',
                         files={str(p): hashlib.sha256(p.read_bytes()).hexdigest()
                                for p in (CHECKPOINT, GEOMETRY, fit_path)}))
    endpoint, practice_rows, contacts, reaches, native_gain = target_practice(state, practice)
    camera_reach = median(reaches)
    source_gain = fit['fit'][0] / camera_reach
    save(OUT / 'shot-target-practice-state.json', endpoint)
    save(OUT / 'shot-target-practice-rows.json', practice_rows)
    save(OUT / 'shot-cross-game-fits.json', dict(pong_angle_gain=native_gain,
        hockey_normalized_gain=fit['fit'][0], hockey_in_pong_image_units=source_gain,
        camera_reach=camera_reach, camera_reaches=reaches,
        practice_target_state_sha256=digest(endpoint),
        observed_pong_contacts=[x.__dict__ for x in contacts]))
    options = {'archived': (None, state),
               'source_hockey': (replace(geometry, angle_per_offset=source_gain), state),
               'source_reflected': (replace(geometry, angle_per_offset=-source_gain), state),
               'zero_angle': (replace(geometry, angle_per_offset=0.), state),
               'extra_pong_archived': (None, endpoint),
               'extra_pong_fit': (replace(geometry, angle_per_offset=native_gain), endpoint)}
    experiment(options, evaluation, 'shot-cross-game')


if __name__ == '__main__':
    main()
