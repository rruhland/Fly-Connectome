"""Reconstruct native drive bytes and point clocks from stored contact events."""
from hashlib import sha256
import json
from pathlib import Path
import sys


def audit(folder):
    manifest = json.loads((folder / 'manifest.json').read_text())
    counts = {'streams': len(manifest['schedule']), 'conditions': len(manifest['conditions']),
              'native_drive_hashes_checked': 0, 'native_ticks_checked': 0, 'done_points_checked': 0}
    for ordinal, case in enumerate(manifest['schedule']):
        for condition in manifest['conditions']:
            row = json.loads((folder / 'matches' / f'{ordinal:03d}-{condition}.json').read_text())
            assert row['case'] == case
            assert row['ticks'] <= manifest['max_ticks']
            assert row['seconds'] == row['ticks'] / 120
            trace = bytearray([1]) * row['ticks']
            if condition not in ('stationary', 'disconnected'):
                for event, end_tick in zip(row['contacts'], [c['tick'] for c in row['contacts'][1:]] + [row['ticks'] + 1]):
                    drive = event['drive']
                    if event['button'] is None:
                        assert drive == 0
                    else:
                        assert drive == (1 if event['button'] == row['initial_down_button'] else -1)
                    count = end_tick - event['tick']
                    trace[event['tick'] - 1:end_tick - 1] = bytes([drive + 1]) * count
            assert len(trace) == row['ticks']
            assert len(trace) - trace.count(1) == row['physical_motion_ticks']
            assert sha256(trace).hexdigest() == row['drives_sha256']
            ticks = wins = losses = opportunities = returns = goals = 0
            for point in row['points']:
                assert point['start_tick'] == ticks
                ticks += point['physics_ticks']
                assert ticks == point['end_tick']
                score = point['score']
                assert point['completed'] == (score != 0)
                assert not (score == 0 and ticks != row['max_ticks'])
                wins += score == 1
                losses += score == -1
                opportunities += point['own_opportunities']
                returns += point['own_returns']
                goals += point['scored_after_own_return']
                assert point['scored_after_own_return'] == (score == 1 and point['own_returns'] > 0)
                assert point['last_touch_score'] == point['scored_after_own_return']
            assert (ticks, wins, losses, opportunities, returns, goals) == tuple(row[key] for key in
                   ('ticks', 'points_won', 'points_lost', 'own_opportunities', 'own_returns', 'scored_after_own_return'))
            winner = 'own' if wins == row['first_to'] else 'opponent' if losses == row['first_to'] else None
            assert row['winner'] == winner
            counts['native_drive_hashes_checked'] += 1
            counts['native_ticks_checked'] += ticks
            counts['done_points_checked'] += wins + losses
    (folder / 'audit.json').write_text(json.dumps(counts, indent=2) + '\n')
    print(folder.name, counts)


for arg in sys.argv[1:]:
    audit(Path(arg))
