import argparse
import json
from pathlib import Path
from types import SimpleNamespace

import torch

from run_pong_rapid_recovery_qualification import Candidate, changed_events, first_hit, play, read, read_arm, sha


def trace_case(row, acquired, source):
    recorded = []
    actual = Candidate(str(source), 'RapidMotorController', sha(source)).controller()

    class Recorder(actual):
        elapsed_ticks = 0

        def choose(self, entities, baseline_action):
            request, diagnostic = super().choose(entities, baseline_action)
            recorded.append((self.elapsed_ticks, request, diagnostic['intended'], diagnostic['effective_requests']))
            return request, diagnostic

        def observe(self, **kwargs):
            super().observe(**kwargs)
            self.elapsed_ticks += round(120 * kwargs['elapsed_seconds'])

    replay = play(row['case'], 'candidate_changed', acquired, SimpleNamespace(controller=lambda: Recorder))
    if json.loads(json.dumps(replay)) != row:
        raise ValueError(f'replay mismatch for case {row["case"]["index"]}')
    label, expected = row['case']['switch_tick'], [row['case']['mapping'].index(intent) for intent in range(3)]
    contact = changed_events(row)[0]['tick']
    changed = [entry for entry in recorded if label <= entry[0] < contact]
    supported = [dict(tick=tick, intended=intent, request=request, committed=order[intent])
                 for tick, request, intent, order in changed
                 if request != order[intent] and request == expected[intent]
                 and (row['first_correct_tick'] is None or tick < row['first_correct_tick'])]
    class FullOrderOnly(actual):
        def __init__(self, policy, learner):
            super().__init__(policy, learner)
            self.belief.request = lambda intent, previous: self.belief.order[intent]

    ablated = play(row['case'], 'candidate_changed', acquired, SimpleNamespace(controller=lambda: FullOrderOnly))
    ablated_events = changed_events(ablated)
    return dict(index=row['case']['index'], switch_tick=label, contact_tick=contact,
                ablated_first_hit=first_hit(ablated),
                matched_ablated_prefix=ablated['prefix_sha256'] == row['prefix_sha256'],
                matched_ablated_clock=bool(ablated_events and ablated_events[0]['tick'] == contact),
                first_correct_report_tick=row['first_correct_tick'], correct_partial_requests=supported,
                correct_partial_cameras=len(supported))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('root', type=Path)
    parser.add_argument('candidate', type=Path)
    args = parser.parse_args()
    torch.set_num_threads(1)
    shorter = read_arm(args.root / 'primary/baseline', 'shorter')
    chosen = read_arm(args.root / 'primary/candidate', 'candidate_changed')
    acquired = read(args.root / 'checkpoint-acquired.json')
    gains = [row for i, row in chosen.items() if first_hit(row) and not first_hit(shorter[i])]
    cases = [row for row in gains if row['confirmed_correct_tick'] is None
             or row['confirmed_correct_tick'] >= changed_events(row)[0]['tick']]
    results = [trace_case(row, acquired, args.candidate) for row in cases]
    print(json.dumps(dict(gains=len(gains), without_precontact_stable_confirmation=len(cases), diagnostic_replays=results), indent=2))
