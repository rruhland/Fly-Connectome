from concurrent.futures import ProcessPoolExecutor
from dataclasses import asdict
import json
from pathlib import Path
import sys

import numpy as np
import torch

from pong_score_placement import ScorePlacement
from pong_transfer_arena import play
from run_pong_inverse_cycle import save
from run_pong_score_placement import build_controller, summarize
from run_pong_surprise_recovery import exclusions

EXP=Path('/workspace/m1b-experiments')
MIXED=EXP/'pong-mixed-course-20261119-r1'
TIMING=EXP/'pong-timing-qualification-20261119-r2'
SCORE=EXP/'pong-score-placement-20261119-r1'
SCORING=EXP/'pong-score-qualification-20261119-r1'

def read(path):
    return json.loads(path.read_text())

motor=read(TIMING/'checkpoint-acquired.json')
restored=read(TIMING/'checkpoints/restored.json')
qualified=read(SCORE/'score-state-frozen.json')
mixed=read(MIXED/'spec.json')
mixed_results={r['seed']:r for r in read(MIXED/'scoring.json') if r['phase']=='faster_opponent'}
assert len(mixed_results)==12
used,_=exclusions(EXP)
rng=np.random.default_rng(634618230)
schedule={}
schedule['combined']=[dict(seed=row['serve'],policy=row['policy'],speed=.65,lag=12,mapping=[1,2,0],
                           timing=mixed_results[row['serve']]['initial_timing'], duration=16.)
                      for row in mixed['schedules']['faster_opponent']]
for name,speed in [('strong',.65),('weak',.35)]:
    cases=[]
    while len(cases)<8:
        seed=int(rng.integers(1,2147483647))
        if seed not in used and ((seed*48271+1)%2147483647)%2==len(cases)%2:
            used.add(seed)
            cases.append(dict(seed=seed, policy=int(rng.integers(1,2147483647)),speed=speed,
                              lag=0,mapping=[0,1,2],timing=restored,duration=12.))
    schedule[name]=cases

def game(job):
    arm, phase, case=job
    torch.set_num_threads(1)
    score=ScorePlacement(updates_enabled=False) if arm=='center' else ScorePlacement(**qualified,updates_enabled=False)
    c=build_controller(case['policy'],motor,case['timing'],score,timing_updates=True)
    if arm=='risk':
        from pong_risk_aware_placement import RiskAwarePlacement
        c=RiskAwarePlacement(c.timing,c.placement)
    row=play(c,case['seed'],opponent_speed=case['speed'],duration=case['duration'],delay_frames=case['lag'],mapping=case['mapping'])
    row.update(arm=arm, phase=phase, choices=[asdict(x) for x in c.placement.choices],
               cancels=getattr(c,'cancelled',{}), pursuit=getattr(c,'pursuit_floor',None),
               natural_serve_win=int(row['score']==1 and not row['hits']),loss=int(row['score']==-1),timeout=int(row['score']==0))
    print(phase,arm,case['seed'],row['own_hit_win'],row['hits'],row['opportunities'],row['cancels'],row['pursuit'],flush=True)
    return row

if __name__=='__main__':
    out=Path(sys.argv[1])
    arms=sys.argv[2:]
    if arms == ['risk']:
        schedule=read(EXP/'pong-risk-aim-development-baseline-20261119-r1/schedule.json')
    out.mkdir(parents=True,exist_ok=False)
    save(out/'schedule.json',schedule)
    jobs=[(arm,phase,case) for phase, cases in schedule.items() for case in cases for arm in arms]
    rows=[]
    with ProcessPoolExecutor(2) as pool:
        for row in pool.map(game,jobs):
            rows.append(row)
            save(out/'rows.json',rows)
    save(out/'summary.json',{phase:{arm:summarize([row for row in rows if (row['phase'],row['arm'])==(phase,arm)])
                                  for arm in arms} for phase in schedule})
