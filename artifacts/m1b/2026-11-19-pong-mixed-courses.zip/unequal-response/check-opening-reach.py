"""Post-hoc evaluation of the reachable paddle interval on direct slow serves."""

import json
from pathlib import Path

import torch

from fly_connectome.pong import Physics, Pong


directory = Path(__file__).parent
rows = json.loads((directory / 'live.json').read_text())
misses = [row for row in rows if row['phase'] == 'slower' and not row['contacts'][0][1]]
physics = Physics(opponent_speed=.65, tau_activation=.32)
torch.set_num_threads(1)
results = []
for row in misses:
    game = Pong([row['seed'], row['seed']], physics)
    drives = torch.tensor([-1., 1.])
    for tick in range(1800):
        ball = game.ball[0]
        velocity = game.ball_velocity[0]
        plane = physics.paddle_x + physics.ball_radius
        next_x = float(ball[0] + velocity[0] * physics.dt)
        crossing = velocity[0] < 0 and ball[0] >= plane and next_x <= plane
        target = float(ball[1] + velocity[1] * physics.dt)
        if target < physics.ball_radius:
            target = 2 * physics.ball_radius - target
        if target > 1 - physics.ball_radius:
            target = 2 * (1 - physics.ball_radius) - target
        game.step(drives, auto_reset=False)
        if crossing:
            lower, upper = sorted(game.body.position.tolist())
            contact_seconds = (tick + 1) / 120
            assert contact_seconds < 1.
            assert abs(contact_seconds - row['contacts'][0][0]) < 3 / 120
            gap = max(lower - target, target - upper, 0.)
            hit_tolerance = physics.paddle_half + physics.ball_radius
            results.append(dict(seed=row['seed'], contact_seconds=contact_seconds, target=target,
                                reachable_interval=[lower, upper], gap=gap, hit_tolerance=hit_tolerance,
                                reachable=gap <= hit_tolerance))
            break
assert len(results) == len(misses) and all(not row['reachable'] for row in results)
(directory / 'opening-reach.json').write_text(json.dumps(results, indent=2) + '\n')
