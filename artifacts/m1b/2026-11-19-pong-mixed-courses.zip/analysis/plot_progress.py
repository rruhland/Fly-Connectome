from pathlib import Path
import json
import matplotlib.pyplot as plt
import numpy as np
import matplotlib.ticker as tick
base=Path('/workspace/m1b-experiments')
cohorts=[json.loads((base/f'pong-mixed-course-20261119-r3{suffix}'/'summary.json').read_text()) for suffix in 'ab']
phases=['ordinary_scoring','remap_and_delay','faster_opponent','ordinary_again']
fig,axs=plt.subplots(1,2,figsize=(12.5,4.8),gridspec_kw={'width_ratios':[1.1,1]},layout='constrained')
colors=['#a7b2bf','#087b6c']
for ax in axs:
    ax.set_axisbelow(True);ax.grid(axis='x',color='#dfe5e7',linewidth=.6)
    for sp in ax.spines.values():sp.set_visible(False)
    ax.tick_params(axis='both',length=0,labelsize=10);ax.set_xlim(0,120);ax.set_xticks([0,25,50,75,100]);ax.xaxis.set_major_formatter(tick.PercentFormatter(100,0))
def plot(ax,labels,old,new):
    for j,series in enumerate([old,new]):
        for i,(val,total) in enumerate(series):
            y=i+(.19 if j==0 else -.19)
            x=100*val/total
            ax.barh(y,x,height=.31,color=colors[j])
            ax.text(x+1.3,y,f'{val}/{total}',va='center',fontsize=9,color='#233344')
    ax.set_yticks(np.arange(len(labels)),labels);ax.invert_yaxis()
plot(axs[0],['Button remap\nnext return','Hidden delay\nnext return','Scorable opponent\npoint won after return','Fast opponent\nlater returns'],[(12,30),(6,32),(0,32),(76,76)],[(27,30),(21,32),(18,32),(65,66)])
axs[0].set_title('Independent tests of each skill',loc='left',fontweight='bold',fontsize=14)
def count(arm,phase,metric):return sum(c[arm][phase][metric] for c in cohorts)
def row(arm,p):
    return (count(arm,p,'later'),count(arm,p,'later_opportunities')) if p=='faster_opponent' else (count(arm,p,'own_hit_wins'),count(arm,p,'games'))
plot(axs[1],['Ordinary\npoints won after return','Remap + delay\npoints won after return','Fast + remap + delay\nlater returns','Ordinary again\npoints won after return'],[row('center',p) for p in phases],[row('scoring',p) for p in phases])
axs[1].set_title('Two continuous four-state courses',loc='left',fontweight='bold',fontsize=14)
for ax in axs:ax.set_xlabel('Fraction of the indicated opportunities',fontsize=9,color='#454e56')
from matplotlib.patches import Patch
fig.legend(handles=[Patch(color=colors[1],label='Learner'),Patch(color=colors[0],label='Matched comparison')],loc='outside lower center',ncol=2,frameon=False)
fig.savefig('docs/reconstruction/assets/2026-11-19-pong-transfer-progression.png',dpi=160)
