import json,sys
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import numpy as np
import torch
from run_pong_score_placement import build_controller
from pong_transfer_arena import play
from pong_score_placement import ScorePlacement,PlacementEpisode
from run_pong_inverse_cycle import save
from run_pong_mixed_course import summarize
class RecoverAfterDefendedShot(PlacementEpisode):
    def offset(self, approach, intercept, remaining, reachable=(-.4,.4)):
        if self.choices and self.choices[-1].offset and self.choices[-1].approach != approach:
            return 0.
        return super().offset(approach,intercept,remaining,reachable)

def task(arg):
    tag,arm,seed,m,t,s,opponent,lag,mp=arg
    torch.set_num_threads(1)
    sc=ScorePlacement(**s,updates_enabled=False) if arm!='center' else ScorePlacement(updates_enabled=False)
    ctl=build_controller(123,m,t,sc,timing_updates=True)
    if arm=='one': ctl.placement=RecoverAfterDefendedShot(sc,123,0.)
    row=play(ctl,seed,opponent_speed=opponent,delay_frames=lag,mapping=mp,duration=12.)
    return tag,arm,dict(row,updates=0)

if __name__=='__main__':
    base=Path('/workspace/m1b-experiments')
    p=base/'pong-score-one-attempt-dev-20261119';p.mkdir(exist_ok=False)
    checkpoint=json.loads(Path('artifacts/m1b/2026-11-19-pong-transfer-checkpoint.json').read_text())
    rm,rt,rs=(checkpoint[k] for k in ('motor','timing','score'))
    combo=[x['initial_timing'] for x in json.load(open(base/'pong-mixed-course-20261119-r1/scoring.json')) if x['phase']=='faster_opponent'][0]
    rng=np.random.default_rng(66023841);seeds=[]
    while len(seeds)<12:
        s=int(rng.integers(1,2147483647))
        if ((s*48271+1)%2147483647)%2==len(seeds)%2:seeds.append(s)
    cfg=[('scorable',.35,0,(0,1,2),rt),('strong',.65,0,(0,1,2),rt),('combined',.65,12,(1,2,0),combo)]
    jobs=[(tag,arm,s,rm,t,rs,op,lag,mp) for s in seeds for tag,op,lag,mp,t in cfg for arm in ('one','repeated','center')]
    save(p/'spec.json',dict(seeds=seeds,config=cfg))
    data={tag:{arm:[] for arm in ('one','repeated','center')} for tag,*_ in cfg}
    with ProcessPoolExecutor(2) as pool:
        for tag,arm,row in pool.map(task,jobs):
            data[tag][arm].append(row)
            save(p/'rows.json',data)
    save(p/'summary.json',{tag:{a:summarize(rows) for a,rows in groups.items()} for tag,groups in data.items()})
