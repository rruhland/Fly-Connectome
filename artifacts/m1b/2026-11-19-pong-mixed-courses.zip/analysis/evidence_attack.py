"""Pilot positive public evidence of weak coverage before risking a delayed shot."""
import json
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
from collections import deque
import numpy as np
import torch
from pong_risk_aware_placement import RiskAwarePlacement
from pong_score_placement import ScorePlacement
from pong_transfer_arena import play
from run_pong_score_placement import build_controller
from run_pong_inverse_cycle import save
from run_pong_mixed_course import summarize
class CoverageEvidence(RiskAwarePlacement):
    def __init__(self,timing,placement):
        super().__init__(timing,placement)
        self.lagging=deque(maxlen=12)
        self.weak=False
    def _observe_pursuit(self):
        super()._observe_pursuit()
        binding=self.timing.inherited.bound_ids
        lookup={o['id']:o['normalized_position'] for o in self.entities if o['observed']}
        if not binding or not all(i in lookup for i in binding) or self.opponent_id not in lookup: return
        axis=self.timing.axis
        gap=lookup[binding[1]][axis]-lookup[self.opponent_id][axis]
        self.lagging.append(gap)
        if len(self.lagging)>=8:
            a=np.asarray(self.lagging)
            if abs(a[-1])>.115 and (abs(a[-1])-abs(a[0])) >.012 and abs(a.mean())>.095:
                self.weak=True
    def _reason(self,context):
        risk=super()._reason(context)
        if risk: return risk
        if self.timing.delay_commands and not self.weak:
            return 'coverage_unresolved'

def job(j):
    i,op,name,seed,t,sc,mo=j;torch.set_num_threads(1)
    pol=ScorePlacement(**sc,updates_enabled=False) if name!='center' else ScorePlacement(updates_enabled=False)
    c=build_controller(123,mo,t,pol,timing_updates=True)
    c=(CoverageEvidence if name=='evidence' else RiskAwarePlacement)(c.timing,c.placement)
    r=play(c,seed,opponent_speed=op,duration=16.,delay_frames=12,mapping=(1,2,0))
    r.update(updates=0,weak=getattr(c,'weak',None),cancelled=c.cancelled)
    return str(op),name,r
if __name__=='__main__':
    base=Path('/workspace/m1b-experiments')
    p=base/'pong-score-positive-coverage-dev-20261119';p.mkdir(exist_ok=False)
    state=json.loads(Path('artifacts/m1b/2026-11-19-pong-transfer-checkpoint.json').read_text())
    t=next(x['initial_timing'] for x in json.load(open(base/'pong-mixed-course-20261119-r1/scoring.json')) if x['phase']=='faster_opponent')
    rng=np.random.default_rng(62567823);seeds=[]
    while len(seeds)<12:
        s=int(rng.integers(1,2147483647))
        if ((s*48271+1)%2147483647)%2==len(seeds)%2:seeds.append(s)
    rows={str(op):{a:[] for a in ('evidence','guard','center')} for op in (.35,.65)}
    jobs=[(i,op,n,s,t,state['score'],state['motor']) for i,s in enumerate(seeds) for op in (.35,.65) for n in rows[str(op)]]
    save(p/'schedule.json',seeds)
    with ProcessPoolExecutor(2) as pool:
        for op,a,r in pool.map(job,jobs):
            rows[op][a].append(r);save(p/'rows.json',rows)
    save(p/'summary.json',{o:{k:summarize(v) for k,v in arms.items()} for o,arms in rows.items()})
