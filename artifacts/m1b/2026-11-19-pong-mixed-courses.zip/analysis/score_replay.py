"""Render a matched qualification pair and verify the replay against both receipts."""
from pathlib import Path
import json
from unittest.mock import patch
import torch
from PIL import Image, ImageDraw, ImageFont
from pong_score_placement import ScorePlacement
from pong_transfer_arena import play, PongCamera
from run_pong_score_placement import build_controller
torch.set_num_threads(1)
source=Path('/workspace/m1b-experiments/pong-score-qualification-20261119-r1')
schedule=json.loads((source/'schedules.json').read_text())['scoring']
bundle=json.loads(Path('artifacts/m1b/2026-11-19-pong-transfer-checkpoint.json').read_text())
read=lambda path:json.loads(path.read_text())
targets=source/'run/scoring'
for i,seed in enumerate(schedule):
    paths=[targets/arm/f'{seed}.json' for arm in ('center','trained')]
    if not all(f.exists() for f in paths):
        continue
    rows=[read(f) for f in paths]
    if rows[1]['own_hit_win']>rows[0]['own_hit_win']:
        break
else:
    raise RuntimeError('no completed matched example')
step=PongCamera.step
movies=[]
for arm,row in zip(('center','trained'),rows):
    frames=[]
    def capture(camera,action):
        if not frames:
            frames.append((0,camera.game.render(64,64)[0].clone()))
        res=step(camera,action)
        if camera.decisions%3==0 or res.terminated or res.truncated:
            frames.append((camera.total_ticks,res.frame.clone()))
        return res
    scorer=ScorePlacement(**(bundle['score'] if arm=='trained' else {}),updates_enabled=False)
    ctr=build_controller(1245+i,bundle['motor'],bundle['timing'],scorer,timing_updates=True)
    with patch.object(PongCamera,'step',capture):
        replay=play(ctr,seed,opponent_speed=.35,duration=12.)
    assert replay['action_sha256']==row['action_sha256'] and replay['score']==row['score']
    movies.append(frames)
fonts=Path('/usr/share/fonts/truetype/dejavu')
title=ImageFont.truetype(str(fonts/'DejaVuSans-Bold.ttf'),19)
label=ImageFont.truetype(str(fonts/'DejaVuSans.ttf'),15)
result=[]
for tick in range(0,max(fr[-1][0] for fr in movies)+9,8):
    img=Image.new('RGB',(548,351),'#132235')
    d=ImageDraw.Draw(img)
    d.text((13,6),'Same serve, same opponent',font=title,fill='white')
    d.text((13,32),'Agent plays on the left of each court',font=label,fill='#c6d6df')
    for j,(fr,row) in enumerate(zip(movies,rows)):
        pos=next((k-1 for k,(t,f) in enumerate(fr) if t>tick),len(fr)-1)
        pos=max(0,pos)
        ar=fr[pos][1].numpy().astype('uint8')*255
        court=Image.fromarray(ar).resize((256,256),Image.Resampling.NEAREST)
        x=12+268*j
        img.paste(court,(x,77));d.text((x,55),('Center aim','Learned placement')[j],font=label,fill='#79d6bd')
        s='Playing' if pos<len(fr)-1 else ('Point won' if row['score']>0 else 'Point lost' if row['score']<0 else 'Time limit')
        d.text((x,334),f'{fr[pos][0]/120:.1f} s   {s}',font=label,fill='white')
    result.append(img)
out=Path('docs/reconstruction/assets/2026-11-19-pong-shot-comparison.gif')
result[0].save(out,save_all=True,append_images=result[1:],duration=[65]*(len(result)-1)+[1250],loop=0,optimize=True,disposal=1)
print(seed,[(r['score'],r['hits'],r['elapsed']) for r in rows],out.stat().st_size)
