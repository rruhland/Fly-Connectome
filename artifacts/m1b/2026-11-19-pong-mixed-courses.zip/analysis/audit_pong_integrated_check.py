from collections import Counter
from pathlib import Path
import hashlib
import json

ROOT = Path('/workspace/m1b-experiments')
BASE = 'pong-mixed-course-20261119-r3'
ARMS = ('center', 'scoring')
PHASES = ('ordinary_scoring', 'remap_and_delay', 'faster_opponent', 'ordinary_again')


def read(path):
    return json.loads(path.read_bytes())


def digest(data):
    return hashlib.sha256(data).hexdigest()


def verify_lineage(registration):
    entries = registration['inputs']
    timing = Path(entries['timing']['path'])
    lineage_path = timing.parent/'lineage.json'
    assert digest(lineage_path.read_bytes()) == registration['timing_lineage_sha256']
    lineage = read(lineage_path)
    source = lineage['states']['restored']
    receipt_path = Path(source['receipt'])
    summary_path = Path(lineage['qualification_summary'])
    assert digest(summary_path.read_bytes()) == lineage['summary_sha256']
    assert read(summary_path)['qualification']['full_qualification'] and lineage['full_qualification']
    assert digest(receipt_path.read_bytes()) == source['receipt_sha256']
    assert source['state_sha256'] == entries['timing']['sha256']
    phase = next(ep for ep in read(receipt_path)['episodes'] if ep['phase'] == source['phase'])
    assert phase[source['state_field']] == read(timing)
    score_path = Path(entries['score']['path'])
    score_origin = read(score_path.parent/'input.json')
    assert score_origin['timing_checkpoint']['sha256'] == entries['timing']['sha256']
    assert score_origin['motor_checkpoint']['sha256'] == entries['motor']['sha256']
    training = read(score_path.parent/'practice.json')
    assert len(training) == 96 and sum(read(score_path)['visits']) == 78
    return dict(qualified_timing_state_source=digest(receipt_path.read_bytes()),
                qualified_timing_summary=lineage['summary_sha256'], score_training_games=len(training),
                score_terminal_updates=sum(read(score_path)['visits']),
                score_training_receipt_sha256=digest((score_path.parent/'practice.json').read_bytes()))


def counters(rows):
    contact = [row['contacts'] for row in rows if row['contacts']]
    later = [hit for events in contact for _, hit in events[1:]]
    return dict(games=len(rows), own_hit_wins=sum(row['own_hit_win'] for row in rows),
                first=sum(events[0][1] for events in contact), openings=len(contact), later=sum(later),
                later_opportunities=len(later), losses=sum(row['score'] < 0 for row in rows),
                natural_wins=sum(row['score'] > 0 and not row['hits'] for row in rows),
                score_updates=sum(row['updates'] for row in rows))


def carry_state(row, phase):
    name, _, mapping, lag = phase
    assert row['phase'] == name
    final = row['final_timing']
    expected_map = [mapping.index(intent) for intent in range(3)]
    return final['motor_order'] == expected_map and final['delay_commands'] == lag


def validate_phase(rows, phase):
    counts = counters(rows)
    first_settled = next((index for index, row in enumerate(rows, 1) if carry_state(row, phase)), None)
    decisions = Counter(reason for row in rows for reason in row['guarded_approaches'].values())
    return dict(tallies=counts, shot_guard_reasons=dict(decisions), ever_settled_game=first_settled,
                exact_map_and_lag_games=sum(carry_state(row, phase) for row in rows),
                first_game_entry=rows[0]['initial_timing'], last_game_exit=rows[-1]['final_timing'],
                initial_shot_memory=rows[0]['initial_shot_memory'], final_shot_memory=rows[-1]['final_shot_memory'])


def audit_cohort(path, registration):
    spec = read(path/'spec.json')
    schedule_hash = digest(json.dumps(spec['schedules'], sort_keys=True).encode())
    assert schedule_hash == registration['schedules_sha256'][str(spec['schedule_seed'])]
    assert spec['phases'] == registration['phases'] and spec['games_per_phase'] == 16
    assert spec['carry_risk'] and not spec['guarded']
    for name, entry in registration['inputs'].items():
        assert digest(Path(entry['path']).read_bytes()) == entry['sha256'] == spec[f'{name}_sha']
    assert spec['script_sha'] == registration['runtime_sha256']['run_pong_mixed_course.py']
    starting_timing = read(Path(registration['inputs']['timing']['path']))
    starting_score = read(Path(registration['inputs']['score']['path']))
    actual = read(path/'summary.json')
    audited, audit_rows = {}, {}
    for arm in ARMS:
        rows = read(path/f'{arm}.json')
        final = read(path/f'{arm}-final.json')
        scheduled = [(phase, case['serve']) for phase in PHASES for case in spec['schedules'][phase]]
        assert [(row['phase'], row['seed']) for row in rows] == scheduled
        assert rows[0]['initial_timing'] == starting_timing
        assert rows[0]['initial_shot_memory'] == dict(pursuit_floor=0., delayed_win_estimate=.6, skipped_points=0)
        consumed = list(zip(rows, rows[1:]))
        assert all(a['final_timing'] == b['initial_timing'] for a, b in consumed)
        assert all(a['final_shot_memory'] == b['initial_shot_memory'] for a, b in consumed)
        assert final['timing'] == rows[-1]['final_timing'] and final['shot_memory'] == rows[-1]['final_shot_memory']
        initial_updates = sum(starting_score['visits']) if arm == 'scoring' else 0
        assert sum(final['score']['visits']) == initial_updates + sum(row['updates'] for row in rows)
        for row in rows:
            assert row['own_hit_win'] == int(row['score'] > 0 and row['hits'] > 0)
            assert row['hits'] == sum(hit for _, hit in row['contacts'])
            assert row['opportunities'] == len(row['contacts'])
            assert row['elapsed'] <= 20 and row['cameras'] <= 1000
        audited[arm] = {phase[0]: validate_phase(rows[index*16:(index+1)*16], phase)
                        for index, phase in enumerate(spec['phases'])}
        assert {phase: data['tallies'] for phase, data in audited[arm].items()} == actual[arm]
        audit_rows[arm] = rows
    pair_rows = list(zip(*(audit_rows[arm] for arm in ARMS), strict=True))
    same_clock = lambda x: x['contacts'][0][0] if x['contacts'] else None
    assert all(same_clock(a) == same_clock(b) for a, b in pair_rows)
    paired = {}
    for phase in PHASES:
        same_phase = [(r, s) for r, s in pair_rows if r['phase'] == phase]
        paired[phase] = dict(learned_only=sum(not r['own_hit_win'] and s['own_hit_win'] for r, s in same_phase),
                             center_only=sum(r['own_hit_win'] and not s['own_hit_win'] for r, s in same_phase),
                             first_clock_pairs=len(same_phase))
    return dict(schedule_seed=spec['schedule_seed'], paired=paired, arms=audited,
                transitions=sum(row['cameras'] for rows in audit_rows.values() for row in rows), initial_cameras=128,
                identical_first_contact_clocks=len(pair_rows), carry_links_per_arm=63,
                receipt_sha256={file.name: digest(file.read_bytes()) for file in sorted(path.glob('*.json'))})


if __name__ == '__main__':
    registration_path = ROOT/f'{BASE}b-registration.json'
    registration = read(registration_path)
    lineage = verify_lineage(registration)
    both = {name: audit_cohort(ROOT/(BASE+name), registration) for name in ('a', 'b')}
    totals = {arm: {phase: dict(sum((Counter(cohort['arms'][arm][phase]['tallies']) for cohort in both.values()), Counter()))
                    for phase in PHASES} for arm in ARMS}
    gates = registration['gates']
    phases = gates['scorable_phases']
    wins = {arm: sum(totals[arm][phase].get('own_hit_wins', 0) for phase in phases) for arm in ARMS}
    games = sum(totals['center'][phase]['games'] for phase in phases)
    remap = {arm: totals[arm]['remap_and_delay'].get('own_hit_wins', 0) for arm in ARMS}
    strong = {arm: totals[arm][gates['strong_phase']] for arm in ARMS}
    later = {arm: values.get('later', 0)/values['later_opportunities'] for arm, values in strong.items()}
    advantage = (wins['scoring']-wins['center'])/games
    checks = dict(scorable_advantage=advantage >= gates['min_own_hit_win_advantage'],
                  positive_remap_delay=remap['scoring'] > remap['center'],
                  strong_absolute_later=later['scoring'] >= gates['min_strong_later_return_rate'],
                  strong_relative_later=later['scoring'] >= later['center']-gates['max_strong_later_return_loss_vs_center'])
    report = dict(complete=True, passed=all(checks.values()), checks=checks, cohorts=both, pooled=totals, lineage=lineage,
                  scorable_own_hit_wins=wins, scorable_games_per_arm=games, scorable_advantage=advantage,
                  remap_delay_own_hit_wins=remap, strong_later_return_fraction=later,
                  registration_sha256=digest(registration_path.read_bytes()))
    output = ROOT/f'{BASE}-independent-audit.json'
    output.write_text(json.dumps(report, sort_keys=True, indent=2)+'\n')
    print(output, digest(output.read_bytes()), json.dumps({k:v for k,v in report.items() if k!='cohorts'}, sort_keys=True))
