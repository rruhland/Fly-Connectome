"""Choose delayed offense using recent observed score outcomes of earlier attacks."""
from pathlib import Path
import json
import torch
from pong_risk_aware_placement import RiskAwarePlacement
from pong_score_placement import ScorePlacement
from pong_transfer_arena import play
from run_pong_score_placement import build_controller
from run_pong_mixed_course import PHASES,summarize
from run_pong_inverse_cycle import save

class Budget:
    def __init__(self):
        self.value=.6
        self.trials=0
        self.idle=0

    def end(self, attempted, delayed, reward):
        if not delayed:return
        if attempted:
            self.value=.5*self.value+.5*(reward>0)
            self.trials+=1
            self.idle=0
        else:
            self.idle+=1

class BudgetGuard(RiskAwarePlacement):
    def __init__(self,timing,placement,budget):
        super().__init__(timing,placement)
        self.budget=budget
        self.tried=False
        self.delayed=False
    def _reason(self,ctx):
        risk=super()._reason(ctx)
        if risk:return risk
        if self.timing.delay_commands:
            self.delayed=True
            if self.budget.value<.4 and self.budget.idle<5:
                return 'unprofitable_delayed_attack'
            self.tried=True
        return None
    def observe(self,**t):
        super().observe(**t)
        if t['terminated'] or t['truncated']:
            self.budget.end(self.tried,self.delayed,t['reward'])

def run():
    base=Path('/workspace/m1b-experiments');out=base/'pong-score-return-budget-dev-20261119'
    out.mkdir(exist_ok=False)
    torch.set_num_threads(1)
    state=json.loads(Path('artifacts/m1b/2026-11-19-pong-transfer-checkpoint.json').read_text())
    spec=json.loads((base/'pong-mixed-course-20261119-r1/spec.json').read_text())
    sch=spec['schedules'];score=ScorePlacement(**state['score']);timing=state['timing']
    budget=Budget(); rows=[];totals={}
    for phase,op,mapping,lag in PHASES:
        chunk=[]
        for s in sch[phase]:
            c=build_controller(s['policy'],state['motor'],timing,score,timing_updates=True)
            c=BudgetGuard(c.timing,c.placement,budget); before=int(score.visits.sum())
            r=play(c,s['serve'],opponent_speed=op,delay_frames=lag,mapping=mapping,duration=20.)
            timing=c.timing.state()
            r.update(phase=phase,updates=int(score.visits.sum())-before,value=budget.value,idle=budget.idle,tried=c.tried,cancelled=c.cancelled)
            rows.append(r);chunk.append(r);save(out/'rows.json',rows)
        totals[phase]=summarize(chunk)
    save(out/'summary.json',totals)
if __name__=='__main__':run()
