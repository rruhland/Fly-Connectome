"""Exact guarded-placement replay of frozen Pong opponent-transfer starts."""
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import asdict
from hashlib import sha256
import math
from pathlib import Path
import subprocess
import signal
import time

import numpy as np
import torch

from fly_connectome.control.session import model_bytes, source_signature
import pong_transfer_arena as arena
from pong_score_placement import ScorePlacement
from return_metrics import ReturnCounter
from pong_risk_aware_placement import build_risk_aware_controller
from run_pong_score_placement import paired_difference, read, retention_difference, summarize, write
from run_pong_surprise_recovery import reached_deadline

OUT = Path(__file__).resolve().parent
HOME = OUT.parent
BASELINE = HOME / 'pong-score-opponent-transfer-20261119-r1'
COMMIT = 'bbd7f2f'
REPO = Path.cwd()
PRACTICE = HOME / 'pong-score-placement-20261119-r1'
QUALIFIED = HOME / 'pong-timing-qualification-20261119-r2'
CHECKPOINTS = dict(score=PRACTICE / 'score-state-frozen.json',
                   motor=QUALIFIED / 'checkpoint-acquired.json',
                   timing=QUALIFIED / 'checkpoints' / 'restored.json')
SPEEDS = (.33, .37, .40)
ARMS = ('center', 'trained')
STARTS = 12
DURATION = 12.
WALL_SECONDS = 240
WORKERS = 3


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def worker():
    torch.set_num_threads(1)
    signal.signal(signal.SIGALRM, reached_deadline)


def episode(speed, arm, seed, policy_seed, score_state, motor_state, timing_state, deadline):
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        raise TimeoutError('probe native allocation exhausted')
    model = ScorePlacement(**(score_state if arm == 'trained' else {}), updates_enabled=False)
    frozen_before = model.to_state()
    controller = build_risk_aware_controller(policy_seed, motor_state, timing_state, model,
                                              exploration=0., timing_updates=True)
    counter = ReturnCounter()
    previous_counter = arena.ReturnCounter
    arena.ReturnCounter = lambda: counter
    signal.setitimer(signal.ITIMER_REAL, remaining)
    try:
        row = arena.play(controller, seed, opponent_speed=speed, duration=DURATION)
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        arena.ReturnCounter = previous_counter
    assert frozen_before == model.to_state()
    assert row['own_hit_win'] == int(row['score'] > 0 and row['hits'] > 0)
    assert len(row['contacts']) == row['opportunities'] == counter.opportunities
    row.update(speed=speed, arm=arm, policy_seed=policy_seed,
               choices=[asdict(choice) for choice in controller.placement.choices],
               natural_serve_win=int(row['score'] > 0 and not row['hits']),
               loss=int(row['score'] < 0), timeout=int(row['score'] == 0),
               post_own_opponent_returns=counter.post_own_opponent_returns,
               post_own_opponent_opportunities=counter.post_own_opponent_opportunities,
               timing_final=controller.timing.state(), risk_cancellations=controller.cancelled,
               pursuit_floor=controller.pursuit_floor)
    write(OUT / 'rows' / f'{speed:.2f}-{arm}-{seed}.json', row)
    return row


def group(rows):
    report = summarize(rows)
    for key in ('post_own_opponent_returns', 'post_own_opponent_opportunities'):
        report[key] = sum(row[key] for row in rows)
    return report


def main():
    if (OUT / 'spec.json').exists():
        raise FileExistsError('preserve the dispatched experiment')
    model_bytes()
    practice_rows = read(PRACTICE / 'practice.json')
    if len(practice_rows) != 96:
        raise ValueError('expected the frozen endpoint of exactly 96 practice starts')
    states = {role: read(path) for role, path in CHECKPOINTS.items()}
    if sum(states['score']['visits']) <= 0 or states['timing']['delay_commands'] != 0:
        raise ValueError('frozen trained score state and restored timing required')
    baseline_summary = read(BASELINE / 'summary.json')
    baseline_spec = read(BASELINE / 'spec.json')
    assert baseline_summary['complete'] and baseline_summary['games'] == STARTS * len(SPEEDS) * len(ARMS)
    assert baseline_summary['spec_sha256'] == digest(BASELINE / 'spec.json')
    for role, path in CHECKPOINTS.items():
        assert digest(path) == baseline_spec['files'][str(path)], role
    schedule = read(BASELINE / 'schedules.json')
    assert len(schedule) == len(set(row['seed'] for row in schedule)) == STARTS
    assert sum(entry['direction'] for entry in schedule) == STARTS // 2
    (OUT / 'schedules.json').write_bytes((BASELINE / 'schedules.json').read_bytes())
    source_names = list(read(PRACTICE / 'source-pins.json')['sha256'])
    source_names.extend(('scripts/experimental/pong_risk_aware_placement.py',
                         'scripts/experimental/pong_rapid_motor_memory.py',
                         'scripts/experimental/return_metrics.py',
                         'scripts/experimental/public_entity_pong_native.py'))
    files = {}
    for name in source_names:
        frozen = subprocess.check_output(['git', 'show', f'{COMMIT}:{name}'], cwd=REPO)
        assert (REPO / name).read_bytes() == frozen, name
        files[str(REPO / name)] = sha256(frozen).hexdigest()
    baseline_rows = sorted((BASELINE / 'rows').glob('*.json'))
    assert len(baseline_rows) == baseline_summary['games']
    files.update({str(path): digest(path) for path in
                  (*CHECKPOINTS.values(), PRACTICE / 'practice.json',
                   QUALIFIED / 'checkpoints' / 'lineage.json', OUT / 'schedules.json',
                   Path(__file__), BASELINE / 'summary.json', BASELINE / 'spec.json',
                   BASELINE / 'schedules.json', *baseline_rows)})
    spec = dict(contract='paired-fixed-checkpoint-pong-guarded-opponent-transfer-v1',
                starts=STARTS, speeds=SPEEDS, arms=ARMS, episode_seconds=DURATION,
                matched_starts_across_all_conditions=True, directions_each=STARTS // 2,
                timing_updates_live=True, score_updates=False, no_parameter_selection=True,
                center='same deterministic center replayed through the guarded builder',
                learned='guarded original frozen end-of-96-practice scorer',
                metric='own-hit wins divided by all scheduled starts, unopposed serves shown separately',
                workers=WORKERS, wall_seconds=WALL_SECONDS, files=files, source=source_signature(),
                controller_commit=COMMIT, original_spec_sha256=baseline_summary['spec_sha256'])
    write(OUT / 'spec.json', spec)
    spec_digest = digest(OUT / 'spec.json')
    (OUT / 'rows').mkdir()
    start = time.monotonic()
    deadline = start + WALL_SECONDS
    jobs = []
    for i, case in enumerate(schedule):
        for speed in SPEEDS:
            for arm in ARMS if i % 2 == 0 else ARMS[::-1]:
                jobs.append((speed, arm, case['seed'], case['policy_seed'],
                             states['score'], states['motor'], states['timing'], deadline))
    rows = []
    errors = []
    with ProcessPoolExecutor(max_workers=WORKERS, initializer=worker) as pool:
        futures = {pool.submit(episode, *job): job[:3] for job in jobs}
        for future in as_completed(futures):
            try:
                rows.append(future.result())
            except Exception as exc:
                errors.append(dict(job=futures[future], error=repr(exc)))
    seeds = [entry['seed'] for entry in schedule]
    results = {}
    for speed in SPEEDS:
        cohorts = {arm: sorted((row for row in rows if (row['speed'], row['arm']) == (speed, arm)),
                                key=lambda row: seeds.index(row['seed'])) for arm in ARMS}
        paired = None
        if all(len(cohorts[arm]) == STARTS for arm in ARMS):
            center, trained = cohorts['center'], cohorts['trained']
            paired = paired_difference(trained, center)
            yes, no = paired['improved'], paired['regressed']
            n = yes + no
            paired.update(exact_one_sided_p=sum(math.comb(n,k) for k in range(yes,n+1))/2**n,
                          first_opportunity_clock_mismatches=sum(
                              (a['contacts'][0][0] if a['contacts'] else None) !=
                              (b['contacts'][0][0] if b['contacts'] else None)
                              for a, b in zip(center, trained, strict=True)),
                          retention=retention_difference(trained, center))
        original = {}
        for arm in ARMS:
            pairs = [(read(BASELINE / 'rows' / f"{speed:.2f}-{arm}-{row['seed']}.json"), row)
                     for row in cohorts[arm]]
            changed = [dict(seed=new['seed'], original=old['action_sha256'], guarded=new['action_sha256'],
                            original_own_hit_win=old['own_hit_win'], guarded_own_hit_win=new['own_hit_win'])
                       for old, new in pairs if old['action_sha256'] != new['action_sha256']]
            original[arm] = dict(paired_games=len(pairs), changed_action_hash_count=len(changed),
                                 changed_action_hashes=changed,
                                 original_own_hit_wins=sum(old['own_hit_win'] for old, _ in pairs),
                                 guarded_own_hit_wins=sum(new['own_hit_win'] for _, new in pairs),
                                 cancellations=sum(len(new['risk_cancellations']) for _, new in pairs),
                                 identical_game_outcomes=sum(
                                     (old['score'],old['contacts'],old['cameras']) ==
                                     (new['score'],new['contacts'],new['cameras'])
                                     for old, new in pairs))
        results[f'{speed:.2f}'] = dict(arms={arm: group(cohorts[arm]) for arm in ARMS}, paired=paired,
                                      against_original=original)
    assert all(digest(Path(path)) == expected for path, expected in files.items())
    assert source_signature() == spec['source'] and digest(OUT / 'spec.json') == spec_digest
    summary = dict(complete=len(rows) == len(jobs) and not errors, errors=errors, results=results,
                   games=len(rows), transitions=sum(row['cameras'] for row in rows), initial_cameras=len(rows),
                   wall_seconds=time.monotonic() - start, spec_sha256=spec_digest,
                   all_center_actions_identical=all(report['against_original']['center']['paired_games']==STARTS
                       and report['against_original']['center']['changed_action_hash_count']==0
                       for report in results.values()))
    write(OUT / 'summary.json', summary)
    print(summary, flush=True)


if __name__ == '__main__':
    main()
