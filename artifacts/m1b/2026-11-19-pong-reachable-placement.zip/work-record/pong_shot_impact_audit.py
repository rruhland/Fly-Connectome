from pathlib import Path
import json
from unittest.mock import patch

import torch

import pong_transfer_arena as arena
from pong_reachable_placement import GuardedScorePlacement, ShotGeometry
from run_pong_score_placement import build_controller, ScorePlacement

root=Path('/workspace/m1b-experiments/pong-guarded-score-development-20261119-r1')
inputs=json.loads((root/'inputs.json').read_bytes())
spec=json.loads((root/'spec.json').read_bytes())
conditions={row['seed']:row for row in spec['starts']}
geometry=ShotGeometry(**inputs['geometry']['geometry'])
records=json.loads((root/'rows.json').read_bytes())
active=[]


class ImpactCounter(arena.ReturnCounter):
    def step(self,game,step,drive,**options):
        previous=self.opportunities
        result=super().step(game,step,drive,**options)
        if self.opportunities!=previous:
            position=float(game.body.position[0])
            ball=float(game.ball[0,1])
            active.append(dict(seconds=int(game.rally_steps[0])/120., paddle_y=position,
                ball_y=ball, contact_gap=ball-position, hit=bool(result.hits[0])))
        return result


torch.set_num_threads(1)
audits=[]
for row in records:
    if row['arm']!='guarded_score' or not row['choices'] or row['hits']==row['opportunities']:
        continue
    game=conditions[row['seed']]
    policy=ScorePlacement(**inputs['frozen_score'],updates_enabled=False)
    outer=build_controller(0,inputs['motor'],row['initial_timing'],policy,timing_updates=True)
    controller=GuardedScorePlacement(outer.timing,geometry,outer.placement)
    active.clear()
    with patch.object(arena,'ReturnCounter',ImpactCounter):
        result=arena.play(controller,row['seed'],opponent_speed=game['speed'],duration=8.,delay_frames=game['lag'],mapping=game['mapping'])
    assert result['action_sha256']==row['action_sha256'] and result['contacts']==[tuple(pair) for pair in row['contacts']]
    impact=dict(seed=row['seed'],phase=row['phase'],choices=row['choices'],impacts=active.copy(),matched_action_hash=True)
    audits.append(impact)
    print(impact,flush=True)
(root/'selected-impact-audit.json').write_text(json.dumps(audits,indent=2))
