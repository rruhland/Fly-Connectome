from pathlib import Path
import dataclasses
import hashlib
import json
import sys
import time

import numpy as np
import torch

from pong_reachable_placement import ReachablePlacement, ShotGeometry
from pong_transfer_arena import play
from run_pong_score_placement import build_controller, ScorePlacement, summarize

root=Path(sys.argv[1]); cp=json.loads((root/'checkpoints.json').read_bytes())
geo_data=(root/'geometry-final.json').read_bytes()
geometry=ShotGeometry(**json.loads(geo_data)['geometry'])
games=[row for row in json.loads((root/'schedules.json').read_bytes()) if row['role']=='evaluate']
assert len(games)==16
arms=('aim','projected_center')
code=Path('/workspace/pong-observer/scripts/experimental/pong_reachable_placement.py')
(root/'scout-spec.json').write_text(json.dumps(dict(scope='matched development, half left/right launches, no qualification starts', games=games,
    arms=arms, model_sha256=hashlib.sha256(geo_data).hexdigest(), code_sha256=hashlib.sha256(code.read_bytes()).hexdigest(), duration_seconds=12, workers=1),indent=2))
torch.set_num_threads(1)
rows=[]
began=time.monotonic()
for index,g in enumerate(games):
    for arm in (arms if index%2==0 else reversed(arms)):
        ordinary=build_controller(0,cp['motor'],cp['timing'],ScorePlacement(updates_enabled=False))
        controller=ReachablePlacement(ordinary.timing,geometry,aimed=arm=='aim')
        row=play(controller,g['seed'],opponent_speed=g['speed'],duration=12.)
        row.update(arm=arm, opponent=g['speed'], choices=[dict(at=t,duration=dt,intercept=intercept,offset=offset,predicted_clearance=clear) for t,dt,intercept,offset,clear in controller.shots],
            safety_reductions=controller.safety_reductions,natural_serve_win=int(row['score']==1 and not row['hits']), loss=int(row['score']==-1),timeout=int(row['score']==0))
        rows.append(row)
        (root/'scout-rows.json').write_text(json.dumps(rows,indent=1))
        print(index,g['speed'],arm,row['own_hit_win'],row['hits'],row['opportunities'],[(round(q[3],3),round(q[4],3)) for q in controller.shots],flush=True)
summary=dict(elapsed=time.monotonic()-began, arms={str(opponent):{arm:summarize([r for r in rows if r['opponent']==opponent and r['arm']==arm]) for arm in arms} for opponent in [.35,.65]})
(root/'scout-summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
