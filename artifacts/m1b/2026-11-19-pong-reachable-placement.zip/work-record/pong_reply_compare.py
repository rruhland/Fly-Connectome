from pathlib import Path
import json
import time
from collections import Counter

import torch

from pong_reachable_placement import OutboundReplyPlacement, ShotGeometry
from pong_transfer_arena import play
from run_pong_score_placement import build_controller, ScorePlacement

root=Path('/workspace/m1b-experiments/pong-guarded-score-development-20261119-r1')
inputs=json.loads((root/'inputs.json').read_bytes())
spec=json.loads((root/'spec.json').read_bytes())
cases=[row for row in spec['starts'] if row['phase']=='mixed_fast']
base={r['seed']:r for r in json.loads((root/'rows.json').read_bytes()) if r['arm']=='guarded_score' and r['phase']=='mixed_fast'}
assert len(cases)==6 and len(base)==6
geometry=ShotGeometry(**inputs['geometry']['geometry'])
torch.set_num_threads(1)
rows=[]
began=time.monotonic()
for case in cases:
    seed=case['seed']
    score=ScorePlacement(**inputs['frozen_score'],updates_enabled=False)
    base_result=base[seed]
    outer=build_controller(0,inputs['motor'],base_result['initial_timing'],score,timing_updates=True)
    system=OutboundReplyPlacement(outer.timing,geometry,outer.placement)
    result=play(system,seed,opponent_speed=case['speed'],duration=8.,delay_frames=case['lag'],mapping=case['mapping'])
    assert score.to_state()==inputs['frozen_score']
    result.update(reply_moves=system.reply_moves,new_choices=[list(s) for s in system.shots])
    rows.append(result)
    (root/'outbound-reply-scout.json').write_text(json.dumps(rows,indent=2))
    print(seed,'prior',base_result['contacts'],'new',result['contacts'],'casts',system.reply_moves,flush=True)

def stats(rows):
    return dict(first=[sum(r['contacts'][0][1] for r in rows if r['contacts']),sum(bool(r['contacts']) for r in rows)],
                later=[sum(sum(event[1] for event in r['contacts'][1:]) for r in rows),sum(max(0,len(r['contacts'])-1) for r in rows)],
                own_hit_wins=sum(r['own_hit_win'] for r in rows))
report=dict(scope='retrospective six prior mixed development starts, no qualification starts',
    comparison=stats(list(base.values())), prediction=stats(rows), wall_seconds=time.monotonic()-began)
(root/'outbound-reply-summary.json').write_text(json.dumps(report,indent=2))
print(report)
