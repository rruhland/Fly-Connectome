from pathlib import Path
import hashlib
import json
import math
import time

import torch

from pong_reachable_placement import GuardedScorePlacement, OutboundReplyPlacement, ShotGeometry
from pong_transfer_arena import play
from run_pong_score_placement import build_controller, ScorePlacement

root=Path('/workspace/m1b-experiments/pong-guarded-score-development-20261119-r1')
inputs=json.loads((root/'inputs.json').read_bytes())
spec=json.loads((root/'spec.json').read_bytes())
cases=[row for row in spec['starts'] if row['phase']=='mixed_fast']
base={r['seed']:r for r in json.loads((root/'rows.json').read_bytes()) if r['arm']=='guarded_score' and r['phase']=='mixed_fast'}
geometry=ShotGeometry(**inputs['geometry']['geometry'])


class Requests:
    def __init__(self, controller):
        self.controller=controller
        self.requests=bytearray()

    def choose(self, entities, baseline):
        action, details=self.controller.choose(entities,baseline)
        self.requests.append(action)
        return action,details

    def observe(self, **transition):
        self.controller.observe(**transition)


def stats(rows):
    return dict(first=[sum(r['contacts'][0][1] for r in rows if r['contacts']),sum(bool(r['contacts']) for r in rows)],
                later=[sum(sum(event[1] for event in r['contacts'][1:]) for r in rows),sum(max(0,len(r['contacts'])-1) for r in rows)],
                own_hit_wins=sum(r['own_hit_win'] for r in rows))


torch.set_num_threads(1)
paired=[]
began=time.monotonic()
for case in cases:
    seed=case['seed']
    pair={}
    for arm, implementation in (('incoming_only',GuardedScorePlacement),('outbound_preposition',OutboundReplyPlacement)):
        score=ScorePlacement(**inputs['frozen_score'],updates_enabled=False)
        outer=build_controller(0,inputs['motor'],base[seed]['initial_timing'],score,timing_updates=True)
        system=implementation(outer.timing,geometry,outer.placement)
        recorder=Requests(system)
        result=play(recorder,seed,opponent_speed=case['speed'],duration=8.,delay_frames=case['lag'],mapping=case['mapping'])
        assert score.to_state()==inputs['frozen_score']
        if arm=='incoming_only':
            assert result['action_sha256']==base[seed]['action_sha256']
        first_camera=math.ceil(round(result['contacts'][0][0]*120)*5/12)
        result.update(reply_moves=getattr(system,'reply_moves',0),new_choices=[list(s) for s in system.shots],
            first_action_sha256=hashlib.sha256(recorder.requests[:first_camera]).hexdigest())
        pair[arm]=result
    paired.append(dict(case=case,**pair))
    (root/'outbound-reply-gated-pairs.json').write_text(json.dumps(paired,indent=2))
    print(seed,[(arm,row['contacts'],row['reply_moves']) for arm,row in pair.items()],flush=True)
report=dict(scope='retrospective six prior mixed development starts, no qualification starts',
    first_action_prefixes_equal=sum(p['incoming_only']['first_action_sha256']==p['outbound_preposition']['first_action_sha256'] for p in paired),
    arms={arm:stats([p[arm] for p in paired]) for arm in ('incoming_only','outbound_preposition')}, wall_seconds=time.monotonic()-began)
(root/'outbound-reply-gated-summary.json').write_text(json.dumps(report,indent=2))
print(report)
