from pathlib import Path
import json
import sys

import numpy as np
import torch

from pong_transfer_arena import play
from run_pong_score_placement import build_controller, ScorePlacement
from run_pong_surprise_recovery import exclusions, MODULUS


class PublicRecorder:
    def __init__(self, controller):
        self.controller = controller
        self.rows = []

    def choose(self, entities, baseline_action):
        action, diagnostic = self.controller.choose(entities, baseline_action)
        timing = self.controller.timing
        binding = timing.inherited.bound_ids
        observed = {e['id']: e['normalized_position'] for e in entities if e['observed']}
        if binding is None:
            own = ball = opponent = None
        else:
            own, ball = (observed.get(i) for i in binding)
            others = [p for identity, p in observed.items() if identity not in binding]
            opponent = next(iter(others)) if len(others) == 1 else None
        self.rows.append([timing.seconds, own, ball, opponent])
        return action, diagnostic

    def observe(self, **kwargs):
        self.controller.observe(**kwargs)


root = Path('/workspace/m1b-experiments')
prior = root/'pong-timing-qualification-20261119-r2'
motor = json.loads((prior/'checkpoint-acquired.json').read_text())
timing = json.loads((prior/'checkpoints/restored.json').read_text())
used,_=exclusions(root)
for file in (Path('/workspace/scratch/pong-rapid-qualification-20261119-v1/primary-schedules.json'),Path('/workspace/scratch/pong-rapid-qualification-20261119-v1/reserve-schedules.json'),Path('/workspace/scratch/continuous-unseen-schedule.json')):
    used.update(row['seed'] for row in json.loads(file.read_bytes()))
rng = np.random.default_rng(1083214217)
games=[]
for i in range(24):
    while True:
        seed=int(rng.integers(1,MODULUS))
        if seed not in used and ((seed*48271+1)%MODULUS)%2==(i//2)%2:
            used.add(seed)
            games.append(dict(seed=seed, speed=(.35,.65)[i%2], role='capture' if i<8 else 'evaluate'))
            break
out=Path(sys.argv[1])
out.mkdir()
(out/'schedules.json').write_text(json.dumps(games,indent=2))
(out/'checkpoints.json').write_text(json.dumps(dict(motor=motor,timing=timing),indent=2))
torch.set_num_threads(1)
for i, game in enumerate(games[:8]):
    # Random offset commitments excite contact directions. Only public trajectories are recorded.
    policy=ScorePlacement(updates_enabled=False)
    controller=PublicRecorder(build_controller(i+3417,motor,timing,policy,exploration=1.,forecast_center=True))
    play(controller,game['seed'],opponent_speed=game['speed'],duration=12.)
    (out/f'capture-{i:03d}.json').write_text(json.dumps(controller.rows,separators=(',',':')))
    print(game,len(controller.rows),flush=True)
