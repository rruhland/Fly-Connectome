from pathlib import Path
import hashlib
import json
import sys
import time

import numpy as np
import torch

from pong_reachable_placement import GuardedScorePlacement, ShotGeometry
from pong_transfer_arena import play
from run_pong_score_placement import build_controller, ScorePlacement, summarize
from run_pong_surprise_recovery import exclusions, MODULUS


def read(path):
    return json.loads(path.read_bytes())


def save(path, value):
    temporary=path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value,indent=2))
    temporary.replace(path)


if __name__=='__main__':
    out=Path(sys.argv[1]);out.mkdir()
    root=Path('/workspace/m1b-experiments')
    source=Path('/workspace/scratch/pong-reach-placement-20261119-r1')
    geo_file=source/'geometry-final.json'
    geometry=ShotGeometry(**read(geo_file)['geometry'])
    current=read(source/'checkpoints.json')
    score_file=root/'pong-score-placement-20261119-r1/score-state-frozen.json'
    score=read(score_file)
    mixed_root=root/'pong-mixed-course-20261119-r1'
    mixed=[row for row in read(mixed_root/'center.json') if row['phase']=='remap_and_delay'][-1]['final_timing']
    assert mixed['delay_commands']==12 and mixed['motor_order']==[2,0,1]
    used,metadata=exclusions(root)
    used.update(row['seed'] for row in read(source/'schedules.json'))
    used.update(case['serve'] for group in read(mixed_root/'spec.json')['schedules'].values() for case in group)
    rng=np.random.default_rng(986638113)
    games=[]
    for phase,count,speed,lag,mapping in [('mixed_fast',6,.65,12,(1,2,0)),('ordinary_slow',4,.35,0,(0,1,2)),('ordinary_fast',4,.65,0,(0,1,2))]:
        for i in range(count):
            while True:
                seed=int(rng.integers(1,MODULUS))
                if seed not in used and ((seed*48271+1)%MODULUS)%2==i%2:
                    used.add(seed)
                    games.append(dict(phase=phase,seed=seed,speed=speed,lag=lag,mapping=mapping))
                    break
    code=Path('/workspace/pong-observer/scripts/experimental/pong_reachable_placement.py')
    arms=('guarded_score','guarded_center')
    inputs=dict(motor=current['motor'],ordinary_timing=current['timing'],mixed_timing=mixed,frozen_score=score,geometry=read(geo_file))
    save(out/'inputs.json',inputs)
    save(out/'spec.json',dict(scope='development; fresh and matched; exact frozen rank used by one arm with shared interception projection',
        starts=games,arms=arms, duration=8., workers=1, hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest()
            for p in (geo_file,score_file,code,out/'inputs.json',mixed_root/'center.json')}, excluded_metadata=metadata))
    torch.set_num_threads(1)
    rows=[]
    began=time.monotonic()
    for index,game in enumerate(games):
        timing=mixed if game['lag'] else current['timing']
        for arm in (arms if index%2==0 else reversed(arms)):
            frozen=ScorePlacement(**score,updates_enabled=False)
            outer=build_controller(0,current['motor'],timing,frozen,timing_updates=True)
            controller=GuardedScorePlacement(outer.timing,geometry,outer.placement,aimed=arm=='guarded_score')
            row=play(controller,game['seed'],opponent_speed=game['speed'],duration=8.,delay_frames=game['lag'],mapping=game['mapping'])
            assert frozen.to_state()==score
            row.update(arm=arm,phase=game['phase'],choices=[dict(at=t,duration=dt,intercept=intercept,offset=offset) for t,dt,intercept,offset,_ in controller.shots],
                       safety_reductions=controller.safety_reductions,natural_serve_win=int(row['score']==1 and not row['hits']),loss=int(row['score']==-1),timeout=int(row['score']==0),
                       initial_timing=timing,final_timing=controller.timing.state())
            rows.append(row)
            save(out/'rows.json',rows)
            print(index,game['phase'],arm,row['own_hit_win'],row['hits'],row['opportunities'],[(round(q[3],3)) for q in controller.shots],flush=True)
    summary=dict(elapsed=time.monotonic()-began, arms={group:{arm:summarize([r for r in rows if r['phase']==group and r['arm']==arm]) for arm in arms} for group in ('mixed_fast','ordinary_slow','ordinary_fast')})
    save(out/'summary.json',summary);print(json.dumps(summary,indent=2))
