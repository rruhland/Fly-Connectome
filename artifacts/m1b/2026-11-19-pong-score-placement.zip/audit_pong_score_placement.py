"""Reconstruct score tables from placement receipts without running the arena."""

import argparse
from collections import Counter
import json
import math
from pathlib import Path


def read(path):
    return json.loads(path.read_text())


def audit(root):
    inputs = read(root / 'input.json')
    schedule = read(root / 'schedule.json')
    policy_schedule = read(root / 'policy-rng.json')['streams']
    practice = read(root / 'practice.json')
    learned = read(root / 'score-state-frozen.json')

    counts = [[0.] * 3 for _ in inputs['candidate_offsets']]
    totals = [[0.] * 3 for _ in inputs['candidate_offsets']]
    visits = [0] * len(counts)
    credited = Counter()
    for row in practice:
        assert row['assignment_updated'] == bool(row['choices'])
        assert not row['natural_serve_win'] or not row['choices']
        if not row['choices']:
            continue
        choice = row['choices'][-1]
        arm, intercept = choice['arm'], abs(choice['intercept'])
        weights = [math.exp(-.5 * ((intercept - center) / .11) ** 2)
                   for center in (.04, .22, .41)]
        weight_sum = sum(weights)
        visits[arm] += 1
        credited[arm, row['score']] += 1
        for index, weight in enumerate(weights):
            counts[arm][index] += weight / weight_sum
            totals[arm][index] += row['score'] * weight / weight_sum
    assert learned['visits'] == visits
    for field, replay in [('counts', counts), ('totals', totals)]:
        for arm, recorded in enumerate(learned[field]):
            assert all(math.isclose(x, y, abs_tol=1e-12)
                       for x, y in zip(recorded, replay[arm], strict=True))
    assert learned == read(root / 'score-state.json')

    def audit_group(rows, phase):
        assert [r['seed'] for r in rows] == schedule[phase]
        assert [r['policy_seed'] for r in rows] == policy_schedule[phase]
        for r in rows:
            assert r['score'] == r['own_hit_win'] + r['natural_serve_win'] - r['loss']
            assert r['own_hit_win'] + r['natural_serve_win'] + r['loss'] + r['timeout'] == 1
            assert r['hits'] == sum(bool(c[1]) for c in r['contacts'])
            assert r['opportunities'] == len(r['contacts'])
            assert not r['own_hit_win'] or r['hits'] > 0
            assert not r['natural_serve_win'] or r['hits'] == 0
            assert not r['natural_serve_win'] or not r['choices']
    audit_group(practice, 'practice')
    native_ids = [i for sub in schedule.values() for i in sub]
    policy_ids = [i for sub in policy_schedule.values() for i in sub]
    assert len(native_ids) == len(set(native_ids)) == len(set(policy_ids))
    assert not set(native_ids) & set(policy_ids)
    result = dict(practice_rows=len(practice), updates=sum(visits), visits=visits,
                  raw_score_labels={str(k): v for k, v in credited.items()},
                  state_reconstruction_exact_tolerance=1e-12,
                  serve_and_policy_random_streams_disjoint=True)
    if (root / 'frozen.json').exists():
        frozen = read(root / 'frozen.json')
        for phase, arms in frozen.items():
            for rows in arms.values():
                audit_group(rows, phase)
            naturals = [[r['natural_serve_win'] for r in rows] for rows in arms.values()]
            assert all(n == naturals[0] for n in naturals)
        result['frozen_rows'] = sum(len(rows) for group in frozen.values() for rows in group.values())
        result['equal_natural_serve_wins_on_paired_starts'] = True
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', type=Path)
    args = parser.parse_args()
    print(json.dumps(audit(args.root), indent=2, sort_keys=True))
