# First terminal-score placement run

The run used the Stage 2 v3 restored timing and motor data in upstream. The input receipt records the original paths and content hashes. The source directory contains the pinned learner, runner, arena and physics files for verification alongside the repository at the listed commit.

The practice log records the sequential exposure and terminal score assignments. The frozen log contains the separate internal paired trials. The independent qualification is a distinct run.

After extracting the archive, run `python audit_pong_score_placement.py .` from the extraction directory to reconstruct updates and validate counts without new Pong observations.
