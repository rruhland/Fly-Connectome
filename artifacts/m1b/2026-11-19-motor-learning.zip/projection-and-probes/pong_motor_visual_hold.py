"""Use learned rest during visual gaps and concentrate exploration after failures."""
import numpy as np

from pong_motor_recalibration import MotorGainController, MotorGainLearner


class VisualHoldLearner(MotorGainLearner):
    def perturb(self, action, supported):
        if self.kernel and not self.probe_sequence:
            self.probe_remaining = 0
            return int(action), False
        return super().perturb(action, supported)


class VisualHoldController(MotorGainController):
    def choose(self, public_entities, baseline_action):
        action, decision = super().choose(public_entities, baseline_action)
        if (self.learner.kernel and not decision['ready'] and not decision['dither']
                and (decision['own'] is None or decision['target'] is None)):
            # During occlusion the inherited fallback can keep the actuator moving.
            # Use the least sustained movement learned from the public observations.
            action = int(np.argmin(np.abs(self.learner.gains)))
            self.pending_action = self.inherited.pending_action = action
            decision.update(action=action, mode='learned_rest_during_gap')
        return action, decision
