import sys, json, time
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import torch
from pong_motor_visual_hold import VisualHoldController,VisualHoldLearner
from run_pong_motor_recalibration import POLICY
import run_pong_inverse_cycle as native

def run(arg):
    target,source,replica=arg
    torch.set_num_threads(1)
    policy=native.PersistentRelationalPolicy(native.RelationalPolicy(*POLICY['choices'],POLICY['coefficients'],POLICY['scales']),POLICY['require_first_hit'])
    native.CategoricalMotorController=VisualHoldController
    stream=json.loads((source/'schedules.json').read_text())[replica]
    games={phase:[g for g in stream['games'] if g['phase']==phase] for phase in ('A','B','C','restored')}
    if replica==0:
        model=VisualHoldLearner.from_state(json.loads((source/'candidate-r0-end-A.json').read_text()))
        sequence=games['B'][:16]+games['C'][:16]+games['restored'][:8]
    else:
        model=VisualHoldLearner(stream['probe_seed'])
        sequence=games['A'][:8]+games['B'][:16]+games['C'][:16]+games['restored'][:8]
    rows=[]
    for game in sequence:
        out=native.play(model,policy,game['seed'],game['mapping'])
        rows.append(dict(phase=game['phase'], **out))
        native.save(target/f'r{replica}.json',rows)
    print(replica,len(rows),flush=True)

if __name__=='__main__':
    source=Path('/workspace/m1b-experiments/pong-motor-gain-qualification-20261119-r1')
    dest=source.parent/'public-hold-development-20261119'
    dest.mkdir(exist_ok=False)
    native.save(dest/'plan.json',dict(cameras=88000,starts='fixed first 16 of both hidden and first 8 of restore; rep0 exact end A and rep1 first 8 original A',source=native.sha(Path(VisualHoldLearner.__module__+'.py')) if False else native.sha(Path('scripts/experimental/pong_motor_visual_hold.py'))))
    with ProcessPoolExecutor(2) as pool: list(pool.map(run,[(dest,source,0),(dest,source,1)]))
