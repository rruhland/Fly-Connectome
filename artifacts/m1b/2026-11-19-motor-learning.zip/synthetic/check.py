from itertools import permutations
from pathlib import Path
import json, math
from test_pong_visual_motor_fir import inherited, feedback, QuantizedMotor
from pong_categorical_motor_fir import CategoricalMotorController, CategoricalMotorFIR

def track(model, mapping, frames):
    c = CategoricalMotorController(inherited(),model)
    p = QuantizedMotor()
    p.queue.clear()
    windows=[]
    squared=0
    for t in range(frames):
        act,_=c.choose(p.observation(t),1)
        p.step(mapping[act]-1)
        public=p.observation(t+1)
        c.observe(**feedback(),public_entities=public)
        squared += (public[0]['normalized_position'][0]-public[1]['normalized_position'][0])**2
        if (t+1)%200==0:
            windows.append(math.sqrt(squared/200))
            squared=0
    return windows
m=CategoricalMotorFIR(84491)
track(m,(0,1,2),1400)
output=[]
for mapping in permutations(range(3)):
    live=track(CategoricalMotorFIR.from_state(m.state()),mapping,3800)
    locked=track(m.frozen_branch(),mapping,3800)
    output.append(dict(mapping=mapping,live=live,frozen=locked))
    print(mapping, round((sum(x*x for x in live[-7:])/7)**.5,4), round((sum(x*x for x in locked[-7:])/7)**.5,4),flush=True)
Path(__file__).with_name('outcomes.json').write_text(json.dumps(output))
