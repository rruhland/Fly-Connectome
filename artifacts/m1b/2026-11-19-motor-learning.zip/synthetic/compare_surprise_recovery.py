"""Compare one fixed recovery mechanism on fresh synthetic streams only."""

from concurrent.futures import ProcessPoolExecutor
import hashlib
from itertools import permutations
import json
import math
from pathlib import Path

from pong_categorical_motor_fir import CategoricalMotorController, CategoricalMotorFIR
from surprise_recovery import SurpriseRecoveryFIR
from test_pong_visual_motor_fir import QuantizedMotor, feedback, inherited


SEEDS = (91703, 91709, 91711)
IDENTITY = (0, 1, 2)
DESIGN = {
    'probe_seeds': SEEDS,
    'all_mappings': tuple(permutations(IDENTITY)),
    'acquisition_frames': 1400,
    'changed_frames': 3800,
    'restoration_frames': 1400,
    'reporting_window_frames': 200,
    'late_changed_windows': 7,
    'native_games': 0,
    'prototype_sha256': hashlib.sha256(Path(__file__).with_name('surprise_recovery.py').read_bytes()).hexdigest(),
}


def track(learner, mapping, frames):
    controller = CategoricalMotorController(inherited(), learner)
    plant = QuantizedMotor()
    plant.queue.clear()
    begin_probes = learner.dither_count
    begin_surprises = getattr(learner, 'surprise_episodes', 0)
    squared_error_windows = []
    squared_error = 0.
    for step in range(frames):
        command, _ = controller.choose(plant.observation(step), 1)
        plant.step(mapping[command] - 1)
        observed = plant.observation(step + 1)
        controller.observe(**feedback(), public_entities=observed)
        own, target = (row['normalized_position'][0] for row in observed[:2])
        squared_error += (own - target) ** 2
        if (step + 1) % DESIGN['reporting_window_frames'] == 0:
            squared_error_windows.append(squared_error)
            squared_error = 0.
    assert not squared_error
    return dict(frames=frames, squared_error=sum(squared_error_windows),
        squared_error_windows=squared_error_windows, probe_frames=learner.dither_count - begin_probes,
        surprise_episodes=getattr(learner, 'surprise_episodes', 0) - begin_surprises)


def compare_seed(seed):
    results = []
    for model in (CategoricalMotorFIR, SurpriseRecoveryFIR):
        acquired = model(seed)
        initial = track(acquired, IDENTITY, DESIGN['acquisition_frames'])
        initial_checkpoint = acquired.state()
        for mapping in DESIGN['all_mappings']:
            retained = model.from_state(initial_checkpoint)
            changed = track(retained, mapping, DESIGN['changed_frames'])
            restored = track(retained, IDENTITY, DESIGN['restoration_frames'])
            late = changed['squared_error_windows'][-DESIGN['late_changed_windows']:]
            late_count = DESIGN['reporting_window_frames'] * len(late)
            total_squared_error = sum(phase['squared_error'] for phase in (initial, changed, restored))
            total_frames = sum(phase['frames'] for phase in (initial, changed, restored))
            results.append(dict(seed=seed, model=model.__name__, mapping=mapping,
                initial=initial, changed=changed, restored=restored,
                rmse_initial=math.sqrt(initial['squared_error'] / initial['frames']),
                rmse_changed=math.sqrt(changed['squared_error'] / changed['frames']),
                rmse_restored=math.sqrt(restored['squared_error'] / restored['frames']),
                rmse_late_changed=math.sqrt(sum(late) / late_count),
                rmse_whole=math.sqrt(total_squared_error / total_frames)))
    return results


def main():
    spec = Path(__file__).with_name('surprise-recovery-spec.json')
    outcome = Path(__file__).with_name('surprise-recovery-outcomes.json')
    with spec.open('x') as stream:
        json.dump(DESIGN, stream, indent=2)
    with ProcessPoolExecutor(max_workers=3) as pool:
        rows = [row for result in pool.map(compare_seed, SEEDS) for row in result]
    with outcome.open('x') as stream:
        json.dump(dict(design=DESIGN, results=rows), stream, indent=2)


if __name__ == '__main__':
    main()
