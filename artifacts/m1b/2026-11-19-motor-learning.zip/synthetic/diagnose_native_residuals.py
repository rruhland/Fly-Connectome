"""Replay eight existing normal games to locate false residual alarms without new cameras."""

from collections import deque
import json
from pathlib import Path

import numpy as np

from pong_categorical_motor_fir import CategoricalMotorController, CategoricalMotorFIR
from public_entity_pong_native import load_public_entities
from run_pong_carried_learning import policy_from_entry
from surprise_recovery import SurpriseRecoveryFIR


ROOT = Path('/workspace/m1b-experiments/pong-categorical-neutral-transfer-20261119-r1')
policy = policy_from_entry(json.loads((ROOT / 'spec.json').read_text())['inherited'])
diagnostic = SurpriseRecoveryFIR()
alarms = []
own_positions = []
for game in range(8):
    row = json.loads((ROOT / 'live-0' / f'game-{game:03}.json').read_text())
    original = CategoricalMotorFIR.from_state(row['learner_before'])
    state = diagnostic.state()
    state.update(original.state())
    diagnostic = SurpriseRecoveryFIR.from_state(state)
    controllers = [CategoricalMotorController(policy, learner) for learner in (original, diagnostic)]
    public = load_public_entities(row['public_file'])
    with np.load(row['tape_file'], allow_pickle=False) as archive:
        data = {name: archive[name] for name in archive.files}
    recent = deque(maxlen=20)
    current_tick = 0
    for step, actual in enumerate(data['action']):
        feedback = dict(own_hits=int(data['hits'][step]), reward=float(data['reward'][step]),
            terminated=bool(data['terminated'][step]), truncated=bool(data['truncated'][step]),
            elapsed_seconds=float(data['elapsed_seconds'][step]))
        count = diagnostic.surprise_episodes
        for controller in controllers:
            _, decision = controller.choose(public[step], int(data['baseline_action'][step]))
            controller.pending_action = int(actual)
            controller.inherited.pending_action = int(actual)
            update = controller.observe(**feedback, public_entities=public[step + 1])
        current_tick += int(data['physics_ticks'][step])
        controlled = next((item for item in public[step + 1] if item['id'] == decision['motor_id']), None)
        yz = controlled['normalized_position'] if controlled and controlled['observed'] else None
        recent.append(dict(step=step, actual=int(actual), motor_id=decision['motor_id'],
                           controlled_position=yz, update=update))
        if yz is not None:
            own_positions.append(yz)
        if diagnostic.surprise_episodes != count:
            # Hold the original numerical trajectory and actual public commands fixed.
            diagnostic.covariance = original.covariance.copy()
            ticks = data['opportunity_tick']
            nearest_contact = min((int(t) - current_tick for t in ticks), key=abs, default=None)
            alarms.append(dict(game=game, seed=row['assignment']['seed'], step=step,
                physics_tick=current_tick, nearest_own_opportunity_delta_ticks=nearest_contact,
                recent=list(recent)))
        assert np.array_equal(original.covariance, diagnostic.covariance)
        assert np.array_equal(original.theta, diagnostic.theta)
    assert original.state() == row['learner_after']

result = dict(replayed_normal_games=8, native_observations_added=0, alarms=alarms,
              controlled_position_min=np.min(own_positions, axis=0).tolist(),
              controlled_position_max=np.max(own_positions, axis=0).tolist())
with Path(__file__).with_name('native-normal-residual-diagnostic.json').open('x') as handle:
    json.dump(result, handle)
