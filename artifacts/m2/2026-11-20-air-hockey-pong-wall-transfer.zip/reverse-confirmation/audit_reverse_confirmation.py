"""Independently check matched opening evidence and report first camera revision."""

import argparse
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path

import numpy as np


def audit(directory, root):
    plan = json.loads((directory / 'plan.json').read_text())
    practice = json.loads((directory / 'practice.json').read_text())
    rows = json.loads((directory / 'streams.json').read_text())
    assert len(plan['target']) == len(rows)
    for name, digest in plan['sources'].items():
        archived = directory / 'registered-source' / name
        source = archived if archived.exists() else root / name
        assert sha256(source.read_bytes()).hexdigest() == digest
    assert sum(block['frames'] for block in practice['pong']) == sum(block['frames'] for block in practice['hockey']) == (
        sum(block['frames'] for block in practice['varied_pong']))
    matched_initial_requests = 0
    first_opening_witnesses = 0
    matched_public_witnesses = 0
    summary = {}
    for registered, actual in zip(plan['target'], rows, strict=True):
        assert registered['stream'] == actual['stream'] and registered['restitution'] == actual['restitution']
        arms = actual['arms']
        assert len({arm['lives'][0]['initial_requests_sha256'] for arm in arms.values()}) == 1
        assert len({arm['lives'][0]['initial_estimate'] for arm in arms.values()}) == 1
        matched_initial_requests += 1
        first_reference = None
        for name, arm in arms.items():
            assert [life['seed'] for life in arm['lives']] == [case['seed'] for case in registered['cases']]
            case = arm['lives'][0]
            before_contact_tick = case['first_incoming']['tick']
            public_evidence = [(event['kind'], event['observed_at'], event['coefficient'], event['uncertainty'])
                               for event in arm['events'] if event['course_frame'] * 12 // 5 < before_contact_tick]
            if first_reference is None:
                first_reference = public_evidence
                first_opening_witnesses += len(public_evidence)
            else:
                assert public_evidence == first_reference
            matched_public_witnesses += len(public_evidence)
            track = summary.setdefault(name, {'frames': [], 'early_updates': 0, 'first_hint_updates': 0,
                'returns': 0, 'opportunities': 0, 'first_returns': 0, 'first_opportunities': 0,
                'outcomes': Counter(), 'natural_outcomes': Counter(), 'cameras': 0})
            start = case['initial_estimate']
            update = next((event['course_frame'] for event in arm['events'] if event['estimate'] != start), None)
            track['frames'].append(update)
            track['first_hint_updates'] += bool(arm['events'] and arm['events'][0]['kind'] == 'hint'
                and arm['events'][0]['estimate'] != start)
            track['early_updates'] += bool(update is not None and arm['first_confirmed_frame'] is not None
                                           and update < arm['first_confirmed_frame'])
            for life in arm['lives']:
                track['cameras'] += life['frames']
                track['returns'] += life['own_returns']
                track['opportunities'] += life['own_opportunities']
                incoming = life['first_incoming']
                track['first_returns'] += bool(incoming and incoming['success'])
                track['first_opportunities'] += incoming is not None
                outcome = 'goal' if life['reward'] > 0 else 'loss' if life['reward'] < 0 else 'timed_out'
                track['outcomes'][outcome] += 1
                if not life['bank']:
                    track['natural_outcomes'][outcome] += 1

    rng = np.random.default_rng(61020142)
    pairs = {}
    for arm, stats in summary.items():
        samples = [x for x in stats['frames'] if x is not None]
        stats['median_first_revision'] = float(np.median(samples)) if samples else None
        stats['restricted_mean_first_revision'] = float(np.mean([800 if x is None else min(x, 800)
                                                                 for x in stats['frames']]))
        if arm == 'after_hockey':
            continue
        hockey_frames = summary['after_hockey']['frames']
        differences = np.array([(800 if a is None else min(a, 800)) - (800 if b is None else min(b, 800))
                                for a, b in zip(hockey_frames, stats['frames'], strict=True)])
        draws = rng.integers(len(differences), size=(10000, len(differences)))
        pairs[arm] = {'hockey_earlier': int((differences < 0).sum()), 'tied': int((differences == 0).sum()),
                      'hockey_later': int((differences > 0).sum()), 'difference': float(differences.mean()),
                      'ci95': np.quantile(differences[draws].mean(axis=1), [.025, .975]).tolist()}
    return {
        'matched_initial_request_courses': matched_initial_requests,
        'first_opening_public_evidence_events_per_arm': first_opening_witnesses,
        'matched_first_opening_evidence_events_across_arms': matched_public_witnesses,
        'source_frames_per_additional_practice_arm': sum(block['frames'] for block in practice['hockey']),
        'first_revision_and_game_outcomes': summary,
        'first_revision_hockey_minus_control': pairs,
    }


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory', type=Path)
    parser.add_argument('root', type=Path)
    args = parser.parse_args()
    print(json.dumps(audit(args.directory, args.root), indent=2))
