from dataclasses import replace
import hashlib
import json
from multiprocessing import Pool
from pathlib import Path
import subprocess

import torch

from arcade_transfer_session import CHECKPOINT, TransferSession
from arcade_transfer_schedule import canonical_json
from breakout_arena import breakout_schedule

CANDIDATE = 'a44a795'
ENVIRONMENT_SCHEDULE_SEED = 66234177
POLICY_SEED = 21039075
N_LIVES = 8
MAX_LIFE_TICKS = 1200
OUTPUT = Path('/tmp/arcade-pursuit-revision-counterexample.json')


def replay(locked):
    torch.set_num_threads(1)
    checkpoint = json.loads(CHECKPOINT.read_bytes())
    session = TransferSession('motor_arrival', POLICY_SEED, checkpoint, causal_pursuit=True)
    corrupt_sign = -checkpoint['interception']['choices'][4]
    session.polarity = corrupt_sign
    rows = []
    for index, case in enumerate(breakout_schedule(ENVIRONMENT_SCHEDULE_SEED, N_LIVES), 1):
        state = session.state()
        actor = session.begin_life()
        arena = case.camera(max_episode_ticks=MAX_LIFE_TICKS)
        actor.reset(arena.frame())
        initial_frame = hashlib.sha256(arena.frame().numpy().tobytes()).hexdigest()
        requests = bytearray()
        while not arena.needs_reset:
            request, _ = actor.choose()
            requests.append(request)
            transition = arena.step(request)
            actor.observe(replace(transition, hits=0, physics_ticks=0))
        result = arena.summary()
        session.end_life()
        proposed = session.polarity
        if locked:
            session.polarity = corrupt_sign
        after = session.state()
        rows.append(dict(life=index, polarity_before=state['polarity'], polarity_proposed=proposed,
                         polarity_after=after['polarity'], timing_before=state['timing'],
                         timing_after=after['timing'], credit=after['pursuit_credit'],
                         role=actor.detector.state(), role_seconds=actor.detector.binding_seconds,
                         initial_frame=initial_frame, action_sha256=hashlib.sha256(requests).hexdigest(),
                         initial_state=hashlib.sha256(canonical_json(state)).hexdigest(),
                         final_state=hashlib.sha256(canonical_json(after)).hexdigest(),
                         actual_condition=dict(mapping=arena.mapping, delay=arena.delay_frames),
                         contacts=result['contacts'], returns=result['own_returns'], score=result['score']))
    return rows


if __name__ == '__main__':
    source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
    assert source.startswith(CANDIDATE)
    with Pool(2) as pool:
        revision, fixed = pool.map(replay, (False, True))
    for a, b in zip(revision, fixed, strict=True):
        assert a['initial_frame'] == b['initial_frame']
        assert a['contacts'] and b['contacts']
        assert (a['contacts'][0]['tick'], a['contacts'][0]['ball_x']) == (b['contacts'][0]['tick'], b['contacts'][0]['ball_x'])
    first_revision = next((row['life'] for row in revision if row['credit']['last']['revised']), None)
    results = dict(source_commit=source, scope='single development stream with deliberately inverted pursuit',
                   initially_valid_motor_map=True, lives_per_arm=N_LIVES, max_life_ticks=MAX_LIFE_TICKS,
                   checkpoint_sha256=hashlib.sha256(CHECKPOINT.read_bytes()).hexdigest(),
                   environment_schedule_seed=ENVIRONMENT_SCHEDULE_SEED, policy_seed=POLICY_SEED,
                   first_revision=first_revision, revisable=revision, fixed_corrupt=fixed)
    OUTPUT.write_bytes(canonical_json(results))
    print(dict(first_revision=first_revision,
               openings=[sum(row['contacts'][0]['success'] for row in group) for group in (revision, fixed)],
               returns=[sum(row['returns'] for row in group) for group in (revision, fixed)],
               witness_runs=[[row['credit']['last'] for row in group] for group in (revision, fixed)]))
